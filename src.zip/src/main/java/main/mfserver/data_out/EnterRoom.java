/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.net.PlayerConnection;

import java.io.IOException;

/**
 * @author sevendr
 */
public class EnterRoom extends base {

    public EnterRoom(PlayerConnection client, String roomname) throws IOException {
        super((byte) 5, (byte) 21, client);
        this.buf.writeByte(0);
        this.buf.writeUTF(roomname);

    }

}
