/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.main.Room;

import java.io.IOException;

/**
 * @author sevendr
 */
public class MapData2 extends base {

    public MapData2(Room room) throws IOException {
        super((byte) 5, (byte) 10, room);
        this.buf.writeByte(0);

    }

}
