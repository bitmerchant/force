/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.main.Room;

import java.io.IOException;

/**
 * @author sevendr
 */
public class O_20Sec extends base_old {

    public O_20Sec(Room room) throws IOException {
        super((byte) 6, (byte) 17, room);
    }

}
