/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.net.PlayerConnection;

import java.io.IOException;

/**
 * @author sevendr
 */
public class check_for_ping extends base_old {

    public check_for_ping(PlayerConnection client) throws IOException {
        super((byte) 26, (byte) 11, client);

    }

}
