/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.net.PlayerConnection;

import java.io.IOException;

/**
 * @author sevendr
 */
public class correct_version extends base {

    public correct_version(PlayerConnection client) throws IOException {
        super((byte) 26, (byte) 3, client);
        this.buf.writeInt(0);
        this.buf.writeByte(37);
        this.buf.writeUTF(client.Lang.toLowerCase());
        this.buf.writeUTF(client.Lang.toLowerCase());
        this.buf.writeInt(1263098933);

    }

}
