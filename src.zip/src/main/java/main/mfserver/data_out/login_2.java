/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.data_out;

import mfserver.net.PlayerConnection;

import java.io.IOException;

/**
 * @author sevendr
 */
public class login_2 extends base_old {

    public login_2(PlayerConnection client) throws IOException {
        super(26, 8, client);
        this.objects = new Object[]{client.kullanici.isim, Integer.toString(client.kullanici.code), Integer.toString(client.kullanici.yetki), "0",
                "0"};

    }
}
