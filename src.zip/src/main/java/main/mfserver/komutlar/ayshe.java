package mfserver.komutlar;

import mfserver.net.PlayerConnection;

import java.io.IOException;

public class ayshe extends temel {
    public ayshe(){
        super("ayshe");
    }

    public void isle(PlayerConnection client, String[] args) throws IOException {
        client.sendMessage("<R>I've got that summertime, summertime sadness.");
        if (!client.kullanici.unvanlar.contains(3032)) {
            client.add_event_title(3032, "ayşe");
        }
    }
}
