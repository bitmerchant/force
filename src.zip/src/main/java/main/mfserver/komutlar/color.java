package mfserver.komutlar;

import mfserver.net.PlayerConnection;

import java.io.IOException;

public class color extends temel {
    public color(){
        super("color");
    }

    public void isle(PlayerConnection client, String[] args) throws IOException {
        if (args.length == 1) {
            client.kullanici.kurkRenk = "78583a";
            return;
        }
        client.LuaGame();
        client.room.showColorPicker(777777, client.kullanici.isim, Integer.parseInt(client.kullanici.kurkRenk, 16),
                "Color");

    }
}
