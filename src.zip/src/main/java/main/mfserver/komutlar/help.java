package mfserver.komutlar;

import mfserver.net.PlayerConnection;
import mfserver.util.Dil;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;

public class help extends temel {
    public help(){
        super("help");
    }

    public void isle(PlayerConnection client, String[] args) throws IOException {
        HashSet<temel> temelHashSet=new HashSet<>();
        for (Map.Entry<String, temel> entry:temel.KOMUTLAR.entrySet()){
            temel val=entry.getValue();
            if(val.yetkili(client)&&!val.f_c.equals("help")){
                temelHashSet.add(val);
            }
        }
        ArrayList<String> txt=new ArrayList<>();
        for(temel t:temelHashSet){
            txt.add("<R>/"+t.f_c+"</R> <J>=></J> "+ Dil.yazi(client.Lang,t.getDoc(client)));
        }
        client.sendMessage(StringUtils.join(txt,"\n"));
    }

}
