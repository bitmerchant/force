package mfserver.komutlar;

import mfserver.net.PlayerConnection;

import java.io.IOException;
import java.util.HashMap;

public class temel {
    public static HashMap<String,temel> KOMUTLAR= new HashMap<>();
    public String doc="None";
    public String f_c="";
    public int m_args=0;
    public temel(){

    }
    public temel(String fc){
        this.f_c=fc;
        this.m_args=0;
        this.doc="command_"+fc;
    }
    public temel(String fc,int margs){
        this(fc);
        this.m_args=margs;
    }
    public void isle(PlayerConnection client,String[] args) throws IOException{

    }
    public boolean yetkili(PlayerConnection client){
        return true;
    }
    public String getDoc(PlayerConnection client){
        return doc;
    }
}
