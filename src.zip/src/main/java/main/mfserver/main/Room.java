/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.main;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufOutputStream;
import mfserver.data_out.*;
import mfserver.net.PlayerConnection;
import mfserver.util.*;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.L_Room;
import org.msgpack.MessagePack;
import veritabani.*;

import javax.print.Doc;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author sevendr
 */
public class Room {

    public static final Pattern Official = Pattern.compile(
            "^(village|racing|survivor|defilante|music|vanilla|fastracing|kutier|bootcamp|\\#|)(\\d{3}|\\d{2}|\\d{1}|)$");
    public static final char tire = "-".charAt(0);
    public static final String s_tribe = "*" + (char) 3;
    public static final String char_3 = "" + (char) 3;
    public static final String s_tutorial = (char) 3 + "[tutorial]";
    public static final String s_totem = (char) 3 + "[totem]";
    public static final String s_editeur = (char) 3 + "[editeur]";
    public static final int[] P_Norm = new int[]{0, 1, 4, 9, 5, 8, 14, 6, 7};
    public static final int[] P_Music = new int[]{19};
    public static final int[] P_Defilante = new int[]{18};
    public static final int[] P_Bootcamp = new int[]{13, 3};
    public static final int[] P_Racing = new int[]{17, 17, 7, 17, 17};
    public static final int[] P_Survivor = new int[]{10, 10, 10, 11, 10, 10, 10};
    public static final int[] MAP_LIST = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46,
            47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73,
            74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
            101, 102, 103, 104, 105, 106, 107, 110, 111, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125,
            126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139, 140, 141, 142, 143, 200, 201, 202, 203,
            204, 205, 206, 207, 208, 209, 210, 301, 302, 303, 304, 305, 306, 307, 308, 309};


    public static final HashSet<Integer> M_noshaman = new HashSet<>();
    public static final HashSet<Integer> M_transform = new HashSet<>();

    public static final HashSet<Integer> M_catchcheese = new HashSet<>();
    public static final HashSet<Integer> M_catchcheese_nosham = new HashSet<>();
    private static final String TENGRI_DATA = StringUtils.join(new Object[]{7, 1, 0, 777, 0, 0, 0, "1;0,0,0,0,0,0,0", 0, "ffffff", "95d9d6", 0, ""}, "#");

    static {
        M_noshaman.add(7);
        M_noshaman.add(8);
        M_noshaman.add(14);
        M_noshaman.add(22);
        M_noshaman.add(23);
        M_noshaman.add(28);
        M_noshaman.add(29);
        M_noshaman.add(54);
        M_noshaman.add(57);
        M_noshaman.add(58);
        M_noshaman.add(59);
        M_noshaman.add(60);
        M_noshaman.add(61);
        M_noshaman.add(70);
        M_noshaman.add(77);
        M_noshaman.add(78);
        M_noshaman.add(87);
        M_noshaman.add(88);
        M_noshaman.add(89);
        M_noshaman.add(92);
        M_noshaman.add(122);
        M_noshaman.add(123);
        M_noshaman.add(124);
        M_noshaman.add(125);
        M_noshaman.add(126);
        M_noshaman.add(1007);
        M_noshaman.add(888);
        M_noshaman.add(560);
        M_noshaman.add(200);
        M_noshaman.add(201);
        M_noshaman.add(202);
        M_noshaman.add(203);
        M_noshaman.add(204);
        M_noshaman.add(205);
        M_noshaman.add(206);
        M_noshaman.add(207);
        M_noshaman.add(208);
        M_noshaman.add(209);
        M_noshaman.add(210);
    }

    static {
        M_transform.add(200);
        M_transform.add(201);
        M_transform.add(202);
        M_transform.add(203);
        M_transform.add(204);
        M_transform.add(205);
        M_transform.add(206);
        M_transform.add(207);
        M_transform.add(208);
        M_transform.add(209);
        M_transform.add(210);
    }

    static {
        M_catchcheese.add(110);
        M_catchcheese.add(111);
        M_catchcheese.add(112);
        M_catchcheese.add(113);
    }

    static {
        M_catchcheese_nosham.add(108);
        M_catchcheese_nosham.add(109);
        M_catchcheese_nosham.add(301);
        M_catchcheese_nosham.add(302);
        M_catchcheese_nosham.add(303);
    }

    private final String lowout;
    public boolean isLama = false;
    public boolean isEliteRacing;
    public boolean isTengri;
    public String LuaKey;
    public Map<String, PlayerConnection> clients = new ConcurrentHashMap<>();
    public Map<Integer, PlayerConnection> clients_p = new ConcurrentHashMap<>();
    public String name;
    public String outname;
    public String lang;
    public MFServer server;
    public long Started = -1;
    public int Round = 99;
    public ReentrantLock lock;
    public ReentrantLock lock4;
    public boolean isNormal = false;
    public boolean isMinigame;
    public boolean countStats = true;
    public boolean isTutorial = false;
    public boolean never20secTimer = false;
    public boolean noShaman = false;
    public boolean isEditeur = false;
    public boolean isTotemEditeur = false;
    public int roundTime = 120;
    public int orjroundTime = 120;
    public boolean isMusic = false;
    public boolean isVanilla = false;
    public boolean isBootcamp = false;
    public boolean autoRespawn = false;
    public boolean isSurvivor = false;
    public AtomicInteger mapisReady = new AtomicInteger();
    public boolean isDefilante = false;
    public boolean isRacing = false;
    public boolean isFastRacing = false;
    public boolean is801Room = false;
    public boolean isKutier = false;
    public boolean isMulodrome = false;
    public boolean isTribeHouse = false;
    public boolean isDoubleMap = false;
    public boolean T_20sec;
    public int VampireCode = 0;
    public ScheduledFuture T_newRound;
    public ScheduledFuture T_zamanAt;
    public ScheduledFuture T_Respawn;
    public int currentShamanCode;
    public int forceNextShaman;
    public int forcePerm = -1;
    public map Map;
    public String editeurXML = "";
    public Integer loadedCode = 0;
    public int currentShamanCode2;
    public PlayerConnection[] codes = new PlayerConnection[2];
    public String password = "";
    public map NextMap;
    public Integer NextPerm = null;
    public AtomicInteger numCompleted = new AtomicInteger();
    public int[] Saves;
    public AtomicInteger ObjectID = new AtomicInteger();
    public AtomicInteger TimerID = new AtomicInteger();
    public AtomicInteger ImageID = new AtomicInteger();
    public L_Room l_room;
    public LuaValue lua;
    public boolean isFuncorp = false;
    public boolean autoNewGame = true;
    public boolean autoShaman = true;
    public String LUAFile;
    public HashMap<Integer, ScheduledFuture> runningTimers = new HashMap<>();
    public boolean autoKillAfk = true;
    public boolean AutoTimeLeft = true;
    public boolean ShamanSkills = true;
    public boolean autoScore = true;
    public ArrayList<String> anchors = new ArrayList<>();
    public String community;
    public int maxPlayers = 100;
    public boolean isofficial = false;
    public int Syncer = -1;
    public ArrayList<ArrayList<Integer>> holeCoordinate = new ArrayList<>();
    public ArrayList<ArrayList<Integer>> cheeseCoordinate = new ArrayList<>();
    public HashMap<String, Integer> allShamanSkills = new HashMap<>();
    public int iceCubeCount = 0;
    public ArrayList<ByteBuf> shamanSkillsData;
    public Map<Integer, LuaTable> objectList = new HashMap<>();
    public Integer lastHandyMouseID;
    public Integer lastHandyMouseByte;
    public int cloudId = -1;
    public Tribe tribe;
    public int editeurID = -1;
    public boolean physicalConsumables = false;
    public int editeurPerm = 100;
    public String editeurName = "-";
    public String boss = "";
    public long lastMapTime;
    public boolean event = false;
    public List<MusicVideo> musics = Collections.synchronizedList(new ArrayList());
    public MusicVideo currentVideo;
    public int L_music = 0;
    public HashSet<String> videoVotes = new HashSet<>();
    public boolean isLeveTest;
    public boolean isAgil;
    public boolean isHiddenWater;
    public ConcurrentHashMap<Integer, MulodromePlayer> mulodrome = null;
    public int[] mulodromeStats;
    public boolean mulodromeStart;
    public AtomicInteger mulodromeLock = new AtomicInteger();
    public FuncorpSettings funcorpSettings;
    public int leveTestTime = 0;
    public ArrayList<String> arrComp = new ArrayList<>();
    public ArrayList<An> anlar = new ArrayList<>();
    public boolean isBar = false;
    public HashMap<String, String> miceNames = new HashMap<>();
    public int odaBaslangic = 0;
    public boolean ayna = false;
    public HashSet<String> blockedPlayers = new HashSet<>();
    public int forceAyna = 0;
    public boolean TagsEnabled = true;
    public boolean workEditeur;
    private HashSet<Integer> currentJoints = new HashSet<>();
    private HashSet<Integer> currentPhysicObjects = new HashSet<>();
    private ScheduledFuture startMapTimer;
    private ScheduledFuture T_Vampire;
    private ScheduledFuture T_Afk;
    private AtomicInteger lock2 = new AtomicInteger();
    private PlayerConnection sonKral;
    private ScheduledFuture T_Music;
    private long changedTime;
    private static final int[] keys = new int[]{32, 74, 75, 76, 67, 0, 1, 2, 3, 67};
    public ArrayDeque<DelikVerisi> delikVerileri = new ArrayDeque<>();
    public Long mevcutHid;
    public DelikVerisi mevcutVeri;
    public int sil = 0;
    public long sonEntropi = 0;
    public int entropiSayisi = 0;
    private int mr;

    public Room(MFServer server, String name) {
        this.mapisReady.set(-1);

        this.name = name.trim().replace("<", "").replace(">", "");

        this.server = server;
        if (this.name.startsWith("*")) {
            this.lang = "XX";
            this.community = "INT";
            this.outname = this.name.substring(1);
        } else {
            String[] parts = this.name.split("-", 2);
            this.lang = parts[0].toUpperCase();// ""
            this.community = this.lang;
            this.outname = parts[1];
        }
       /* if (this.lang.equals("E2")) {
            this.lang = "XX";
            this.community = "INT";
            this.name="*"+this.outname;
        }*/
        if (Official.matcher(outname).matches()) {
            this.isofficial = true;
        }
        this.lowout = this.outname.toLowerCase();
        this.lock = new ReentrantLock();
        this.lock4 = new ReentrantLock();
        if (this.outname.startsWith("#")) {
            String mgname = this.outname.substring(1);
            for (Map.Entry<String, MiniOyun> entry : this.server.MINIGAMES.entrySet()) {
                String key = entry.getKey();
                MiniOyun value = entry.getValue();
                if (mgname.startsWith(key)) {
                    this.LuaKey = key;
                    this.LUAFile = value.path;
                    this.isMinigame = true;
                    this.countStats = false;
                    break;
                }

            }
        } else if (this.name.startsWith(s_tribe)) {
            this.countStats = false;
            this.isTribeHouse = true;
            this.noShaman = true;
            this.autoRespawn = true;
            this.roundTime = 10000;
            this.never20secTimer = true;

        } else if (this.lowout.startsWith(s_tutorial)) {
            this.countStats = false;
            this.noShaman = true;
            this.never20secTimer = true;
            this.isTutorial = true;

        } else if (this.lowout.startsWith(s_editeur)) {
            this.countStats = false;
            this.isEditeur = true;
            this.never20secTimer = true;

        } else if (this.lowout.startsWith(s_totem)) {
            this.countStats = false;
            this.isTotemEditeur = true;
            this.roundTime = 360;
            this.never20secTimer = true;

        } else if (this.lowout.contains("music")) {
            this.isMusic = true;

        } else if (this.lowout.contains("vanilla")) {
            this.isNormal = true;
            this.isVanilla = true;

        } else if (this.lowout.contains("bootcamp")) {
            this.isBootcamp = true;
            // this.countStats = false;
            this.roundTime = 360;
            this.never20secTimer = true;
            this.autoRespawn = true;
            this.noShaman = true;

        } else if (this.lowout.startsWith("tengri")) {
            this.isTengri = true;
            this.countStats = false;
            this.roundTime = 120;
            this.never20secTimer = true;
            this.noShaman = true;
            this.autoKillAfk = false;

        } else if (this.lowout.contains("survivor")) {
            this.isSurvivor = true;

        } else if (this.lowout.contains("kutier")) {
            this.ShamanSkills = false;
            this.isKutier = true;

        } else if (this.lowout.contains("defilante")) {
            this.isDefilante = true;
            this.noShaman = true;

        } else if (this.name.equals("*eliteracing")) {
            this.isRacing = true;
            this.isEliteRacing = true;
            this.noShaman = true;
            this.never20secTimer = true;
            this.roundTime = 60;

        } else if (this.lowout.contains("fastracing")) {
            this.isRacing = true;
            this.isFastRacing = true;
            this.noShaman = true;
            this.never20secTimer = true;
            this.roundTime = 60;

        } else if (this.lowout.contains("racing")) {
            this.isRacing = true;
            this.noShaman = true;
            this.never20secTimer = true;
            this.roundTime = 60;

        } else if (this.lowout.equals("lama")) {
            this.isLama = true;
            this.noShaman = true;

        } else if (this.lowout.contains("village")) {
            this.is801Room = true;
            this.LUAFile = "./minigames/Village.lua";
            this.isMinigame = true;
            this.countStats = false;
            this.autoRespawn = true;
            this.roundTime = 9000;

        } else {
            this.isNormal = true;
        }
        this.orjroundTime = this.roundTime;

    }

    public static void iptal(ScheduledFuture t) {
        if (t != null) {
            t.cancel(false);
        }
    }

    public ByteBuf mulodromeRoundData() {
        ByteBuf pack = MFServer.getBuf();
        return pack.writeByte(30).writeByte(4).writeByte(this.Round).writeShort(this.mulodromeStats[0]).writeShort(this.mulodromeStats[1]);
    }

    public ByteBuf mulodromeIptal() {
        return MFServer.getBuf().writeByte(30).writeByte(13);
    }

    public void mulodromeAddPoint(Integer pcode, Integer pos) throws IOException {
        int point = 1;
        if (pos.equals(1)) point = 5;
        MulodromePlayer mulodromePlayer = this.mulodrome.get(pcode);
        if (mulodromePlayer != null) {
            this.mulodromeStats[mulodromePlayer.team] += point;

            this.sendAll(mulodromeRoundData());
        }
    }

    public void mulodromeJoin(Integer pcode) {
        MulodromePlayer found = this.mulodrome.get(pcode);
        if (found != null) {
            MFServer.executor.execute(() -> {
                ByteBufOutputStream bs = MFServer.getStream();
                try {
                    bs.writeByte(30);
                    bs.writeByte(15);
                    bs.writeByte(found.team);
                    bs.writeByte(found.pos);
                    bs.writeInt(MFServer.get_avatar(found.code));
                    bs.writeUTF(found.name);
                    bs.writeUTF(found.tribeName);
                    this.sendAll(bs.buffer());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
    }

    public void mulodromeLeft(Integer pcode) throws IOException {
        MulodromePlayer found = this.mulodrome.remove(pcode);
        if (found != null) {
            this.sendAll(MFServer.getBuf().writeByte(30).writeByte(16).writeByte(found.team).writeByte(found.pos));
        }
    }

    public void playNext() {
        videoVotes.clear();
        this.currentVideo = null;
        if (this.musics.size() > 0) {
            MusicVideo musicVideo = this.musics.remove(0);
            iptal(this.T_Music);
            this.currentVideo = musicVideo;
            try {
                this.sendVideo(null);
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.L_music = MFServer.timestamp();

            this.T_Music = MFServer.executor.schedule(this::playNext, this.currentVideo.sure, TimeUnit.SECONDS);

        }
    }

    public void sendVideo(PlayerConnection target) throws IOException {
        if (this.currentVideo == null) return;
        int sec = 0;
        if (target != null) {
            sec = MFServer.timestamp() - this.L_music;
        }
        ByteBufOutputStream bs = MFServer.getStream();
        bs.writeByte(5);
        bs.writeByte(72);
        bs.writeUTF(this.currentVideo.vid);
        bs.writeUTF(this.currentVideo.title);
        bs.writeShort(sec);
        bs.writeUTF(this.currentVideo.kullanici);
        if (target != null) {
            target.sendPacket(bs.buffer());
        } else {
            this.sendAll(bs.buffer());
        }

    }

    public void create_lua(SRC cb) throws IOException {
        if (this.l_room == null) {
            this.l_room = new L_Room(this, false);
        }
        LUA_THREAD t = new LUA_THREAD(l_room, cb);
        this.server.threads.add(t);
        this.l_room.t = t;
        t.start();
        for (PlayerConnection pc : this.clients.values()) {
            pc.LuaGame();
        }
    }

    public PlayerConnection getFirstShaman() {
        return this.codes[0];
    }

    public PlayerConnection getSecondShaman() {
        return this.codes[1];
    }

    public int get_highest() {

        ArrayList<Integer> scores = new ArrayList<>();
        for (PlayerConnection client : this.clients.values()) {
            scores.add(client.score);
        }
        if (scores.size() == 0) return 0;
        int maxScore = Collections.max(scores);
        for (PlayerConnection client : this.clients.values()) {
            if (client.score == maxScore && client.kullanici != null) {
                return client.kullanici.code;
            }
        }
        return 0;
    }

    public PlayerConnection[] getHighestScore() {
        ArrayList<Integer> scores = new ArrayList<>();
        PlayerConnection player = null;
        PlayerConnection player2 = null;
        PlayerConnection[] _codes = new PlayerConnection[2];
        for (PlayerConnection client : this.clients.values()) {
            scores.add(client.score);
        }
        if (scores.size() == 0) return _codes;

        Integer maxScore = Collections.max(scores);
        if (maxScore == 0) {
            ArrayList<PlayerConnection> cls = new ArrayList<>(this.clients.values());
            if (cls.size() == 0) return _codes;
            Collections.shuffle(cls);
            player = cls.get(0);
            if (this.isDoubleMap && this.clients.size() > 1) {
                player2 = cls.get(1);
            }
        }
        for (PlayerConnection client : this.clients.values()) {
            if (client.score == maxScore) {
                player = client;
                break;
            }
        }
        if (this.isDoubleMap && this.clients.size() > 1) {
            scores.remove(maxScore);

            maxScore = Collections.max(scores);
            for (PlayerConnection client : this.clients.values()) {
                if (client.score == maxScore) {
                    player2 = client;

                }
            }
        }
        _codes[0] = player;
        _codes[1] = player2;
        // allShamanSkills.clear();
        if (player != null && player.kullanici != null) {
            if (player.kullanici.beceriler.get("4") != null)
                player.shamanRespawn = true;
            this.currentShamanCode = player.kullanici.code;
            player.isShaman = true;
            if (ShamanSkills & !isKutier) {
                allShamanSkills = new HashMap<>(player.kullanici.beceriler);
            }
            player.score = 0;
        }
        if (player2 != null && player2.kullanici != null) {
            if (player2.kullanici.beceriler.get("4") != null)
                player2.shamanRespawn = true;
            this.currentShamanCode2 = player2.kullanici.code;
            player2.isShaman = true;
            if (ShamanSkills && !isKutier) {
                for (String skillCode : player2.kullanici.beceriler.keySet()) {
                    if (this.allShamanSkills.containsKey(skillCode)) {
                        if (skillCode.equals("34") || skillCode.equals("23") || skillCode.equals("100")) {
                            continue;
                        }
                        this.allShamanSkills.replace(skillCode,
                                player2.kullanici.beceriler.get(skillCode) + this.allShamanSkills.get(skillCode));
                    } else {
                        this.allShamanSkills.put(skillCode, player2.kullanici.beceriler.get(skillCode));
                    }
                }
            }
            player2.score = 0;
        }

        // this.shamanSkillsData = this.sendShamanSkills();
        return _codes;
    }

    public synchronized void HazirlaSaman() {
        if (this.event) return;
        if (this.currentShamanCode == 0) {
            if (this.forceNextShaman != 0) {

                this.codes = new PlayerConnection[]{this.clients_p.get(this.forceNextShaman), null};
                this.forceNextShaman = 0;
            } else if (this.Map.perm == 0 && Room.M_noshaman.contains(this.Map.id) || this.noShaman || this.Map.perm == 11 || this.Map.perm == 7 || this.Map.perm == 42 || this.Map.perm == 14) {

            } else {
                this.codes = this.getHighestScore();
            }

        }

    }

    public void chech_shaman_feather(PlayerConnection client, int saves) throws IOException {

        if (client.kullanici.samanTur > 2)
            client.kullanici.samanTur = 0;

        if (!this.isSurvivor && !this.isKutier && !client.hidden)
            this.sendAllOld(8, 17, new Object[]{client.kullanici.isim, saves});
        client.score += saves;
        int min;
        int div;
        client.gorevIlerleme(6, saves);
        int op = 1;
        if (client.kullanici.samanTur == 0) {

            client.kullanici.kurtarma += saves;
            client.giveExp(saves * 10 * MFServer.carpan, true, saves);
            min = 3;
            div = 6;

        } else if (client.kullanici.samanTur == 1) {

            client.gorevIlerleme(8, saves);
            client.kullanici.hardKurtarma += saves;
            client.kullanici.kurtarma += saves;
            client.giveExp(saves * 20 * MFServer.carpan, true, saves);
            min = 4;
            div = 5;
            op = 2;
        } else {

            client.gorevIlerleme(7, saves);
            client.kullanici.divineKurtarma += saves;
            client.kullanici.kurtarma += saves;
            client.giveExp(saves * 30 * MFServer.carpan, true, saves);
            min = 5;
            div = 4;
            op = 3;
        }
        int e = Math.min(min, saves / div);
        if (e > 0) {
            client.addInventoryItem(2253, e);
        }
        client.checkAndRebuildTitleList("hard");
        client.checkAndRebuildTitleList("save");
        client.checkAndRebuildTitleList("divine");

        MFServer.updateToRanking(client.kullanici.code, "saves", saves * op, 4 - op, saves);


    }

    public void addClient(PlayerConnection client) throws IOException, InterruptedException {

        addClient(client, 0);
    }

    public void addClient(PlayerConnection client, int sayi) throws IOException, InterruptedException {
        if (client.kullanici == null) return;
        if (this.lock.isLocked() || this.mapisReady.get() == 0) {
            if (sayi > 3) {
                System.out.println("FATAL ERROR BOSS : " + boss);
                System.out.println(client.kullanici.isim);
                if (this.isofficial) {
                    client.sendChatServer("<R>Boss " + boss + " or " + client.kullanici.isim + " using hack tools to glitch room");

                }
                return;
            }
            MFServer.executor.schedule(() -> {
                try {
                    addClient(client, sayi + 1);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, 130, TimeUnit.MILLISECONDS);
            return;
        }
        this.lock.lock();
        try {
            if (client.kullanici != null) {
                this.clients.put(client.kullanici.isim, client);
                this.clients_p.put(client.kullanici.code, client);
                client.room = this;

                int size = this.clients.size();
                client.sendEnterRoom(this.name);
                client.score = 0;
                client.resetPlay();

                client.isDead = true;
                client.sendAnchors.addAll(this.anchors);
                for (Map.Entry<String, PlayerConnection> entry : clients.entrySet()) {
                    if (entry.getValue().kullanici == null) clients.remove(entry.getKey());
                }
                if (!client.hidden) {
                    ByteBufOutputStream bfs = MFServer.getStream();
                    bfs.writeShort(36866);

                    client.writePlayerData(bfs);
                    bfs.writeByte(0);
                    bfs.writeByte(1);
                    //dat = new PlayerList(this).data();
                    this.sendAllOthers(bfs.buffer(), client.kullanici.code);
                    //  this.sendAllOthers(new NewPlayer(client, client.getPlayerData()).data(), client.kullanici.code);
                }
                if ((size == 1 || (size == 2 && !this.isBootcamp && !this.is801Room && !client.hidden)) && this.autoNewGame
                        && !(this.isMinigame && this.l_room == null)) {

                    this.NewRound();

                } else if (size != 1) {
                    client.startPlay(true);
                }
                if (this.l_room != null) {
                    this.l_room.eventNewPlayer(client.kullanici.isim);

                }
                if (size == 1 && this.isMinigame) {
                    String name = client.kullanici.isim;
                    this.create_lua((z) -> {
                        this.l_room.eventNewPlayer(name);
                    });

                }
                client.LuaGame();
                ;
                client.sendPacket(L_Room.packImage("ayar-png.13872", -67, 7, -997, 770, 30));
                client.sendPacket(L_Room.packAddTextArea(-7003, "<a href=\"event:ayar-ac\">\n\n</a>", 770, 30, 30, 40, 0x324650, 0x000000, 0, false));

                if (this.isLama) {
                    client.lamaCount = 0;
                    client.sendMessage("<J>Welcome :)");
                    client.sendLama(0);
                }
            }

        } catch (Exception e) {

            MFServer.log.warning(MFServer.stackTraceToString(e));
        } finally {
            this.lock.unlock();
        }


    }

    public ArrayList<PlayerConnection> findModsInRoom() {
        ArrayList<PlayerConnection> arr = new ArrayList<>();
        for (PlayerConnection pc : this.clients.values()) {
            if (pc.kullanici != null && pc.kullanici.yetki >= 4) {
                arr.add(pc);
            }
        }
        return arr;
    }

    public void removeClient(PlayerConnection client) throws Exception {
        Kullanici kullanici = client.kullanici;
        if (kullanici == null) {
            for (java.util.Map.Entry<String, PlayerConnection> playerConnection : clients.entrySet()) {
                if (playerConnection.getValue() == client) clients.remove(playerConnection.getKey());
            }
            return;
        }
        this.clients.remove(kullanici.isim);
        this.clients_p.remove(kullanici.code);
        if ((this.isLeveTest||this.isAgil||this.isHiddenWater) && kullanici.yetki >= 4) {
            boolean exist = false;
            for (PlayerConnection pc : this.clients.values()) {
                if (pc.kullanici.yetki >= 4) {
                    exist = true;
                    break;
                }
            }
            if (!exist){
                this.isLeveTest = false;
                this.isAgil = false;
                this.isHiddenWater = false;
            }
        }
        if (this.clients.isEmpty()) {
            iptal(this.T_Music);
            this.server.closeRoom(this.name);
            this.codes = new PlayerConnection[2];
            if (this.l_room != null) {
                this.l_room.set_interrupted(true);
                // this.l_room=null;
            }
            return;
        }
        this.sendAllOld(8, 7, new Object[]{kullanici.code, kullanici.isim});

        if (client.isSyncer) {
            this.setSyncer();
            this.sendSync();
        }
        if (VampireCode == kullanici.code) {
            VampireCode = this.get_highest();

        }

        if (this.l_room != null) {
            try {

                this.l_room.eventPlayerLeft(kullanici.isim);
            } catch (Exception e) {
            }
            ;
        }
        if(client.lamaExec!=null){
            client.lamaExec.cancel(false);
        }
        // this.sendAll(new PlayerLeft(client, client.kullanici.code,
        // client.kullanici.isim).data());
    }

    public void sendMessage(String message) throws IOException {
        this.sendAll(MFServer.pack_message(message));
    }

    public void checkShouldChangeCarte() throws IOException {
        if (this.isBootcamp || this.autoRespawn || (this.isTribeHouse) || !this.AutoTimeLeft) {

        } else {
            boolean allDead = true;
            for (PlayerConnection client : this.clients.values()) {
                if (!client.isDead) {
                    allDead = false;
                    break;
                }
            }

            if (allDead) {

                this.NewRound();
                return;
            }

            this.check20sec();
        }
    }

    public void check20sec() throws IOException {
        if (!this.never20secTimer && !this.T_20sec) {
            int total = this.playerCount();
            int alive = this.death_alive()[1];
            byte shadead = 0;
            byte shac = 0;
            if (this.getFirstShaman() != null) {
                shac++;
                if (this.getFirstShaman().isDead) {
                    shadead++;
                }
            }
            if (this.getSecondShaman() != null) {
                shac++;
                if (this.getSecondShaman().isDead) {
                    shadead++;
                }
            }
            if (this.T_newRound != null && this.T_newRound.getDelay(TimeUnit.SECONDS) < 20) return;
            if ((total >= 2 && alive <= 1) || (shadead == shac && shac != 0)) {
                this.T_20sec = true;
                this.set_time(20);
                this.sendAll(new O_20Sec(this).data());

            }

        }
    }

    public void set_time(int time) throws IOException {
        iptal(T_zamanAt);
        iptal(T_newRound);
        if (time != 0) {
            this.sendAll(new RoundTime(this, time).data());
        }
        this.roundTime = time;
        this.changedTime = System.currentTimeMillis();
        if (this.autoNewGame) {
            this.T_newRound = MFServer.RoomExecutor.schedule(() -> {
                try {
                    this.NewRound();
                } catch (Exception e) {
                    MFServer.log.warning(MFServer.stackTraceToString(e));
                }
            }, time, TimeUnit.SECONDS);
        }
    }

    public void sendDeath(PlayerConnection cl) throws IOException {
        if (cl != null && cl.kullanici != null) {
            ByteBuf data = new O_Death(cl).data();

            //  addtoBuffer(data,cl.kullanici.code);
            this.sendAll(data);
            cl.isDead = true;
            if (this.l_room != null) {
                this.l_room.eventPlayerDied(cl.kullanici.isim);
            }
        }

    }

    public void kill_all() throws IOException {
        for (PlayerConnection pc : this.clients.values()) {
            sendDeath(pc);
        }
    }

    public int[] death_alive() {
        int[] a = new int[2];
        for (PlayerConnection client : this.clients.values()) {
            if (client.isDead) {
                a[0]++;
            } else {
                a[1]++;
            }

        }
        return a;
    }

    public ByteBuf getPlayerBuf() throws IOException {
        Collection<PlayerConnection> pcs = this.clients.values().stream().filter(kul -> !kul.hidden).collect(Collectors.toList());
        ByteBufOutputStream bfs = MFServer.getStream();
        bfs.writeShort(36865);
        int size = pcs.size();
        if (isTengri) size += 1;

        bfs.writeShort(size);
        pcs.forEach((p) -> {
            try {
                p.writePlayerData(bfs);
            } catch (IOException e) {
                e.printStackTrace();
            }

        });
        if (isTengri) {

            String _look = "1;0,0,0,0,0,0,0";
            String name = "Tengri";
            if (this.mevcutVeri != null && this.mevcutHid != -1 && this.mevcutVeri.harita == this.Map.id)
                name = "Not Tengri (" + this.mevcutVeri.ad + ") :)";
            bfs.writeUTF(name);//İSİM
            bfs.writeInt(7);//PID
            bfs.writeBoolean(false);
            bfs.writeByte(0);
            bfs.writeShort(0);
            bfs.writeBoolean(false);
            bfs.writeShort(0);//ÜNVAN
            bfs.writeByte(1);
            bfs.writeByte(2);
            bfs.writeUTF("0");
            bfs.writeUTF(_look);
            bfs.writeBoolean(true);
            bfs.writeInt(Integer.parseInt("78583a", 16));
            bfs.writeInt(Integer.parseInt("95d9d6", 16));
            bfs.writeInt(0);
            bfs.writeInt(-1);//İsim renk 3906460

        }
        return bfs.buffer();
    }

    public int playerCount() {
        int i = 0;
        for (PlayerConnection client : this.clients.values()) {
            if (!client.hidden) i++;
        }
        return i;
    }

    public int unique_playerCount() {
        HashSet<String> a = new HashSet<>();
        for (PlayerConnection client : this.clients.values()) {
            if (!client.hidden) a.add(client.ip);
        }
        return a.size();
    }

    public LuaValue[] getRoundTime2() {
        int time = this.roundTime;
        long long1 = (System.currentTimeMillis() - this.Started);
        long long2 = time * 1000 - (System.currentTimeMillis() - this.changedTime);
        if (this.T_newRound != null && !this.T_newRound.isDone()) {
            long2 = this.T_newRound.getDelay(TimeUnit.MILLISECONDS);
        }
        return new LuaValue[]{LuaInteger.valueOf(long1), LuaInteger.valueOf(long2)};
    }

    public int getRoundTime() {
        int time = this.roundTime;
        if (this.Started != -1) {
            return (int) (time - (System.currentTimeMillis() - this.Started) / 1000);
        }
        return time;
    }

    public void runEvent(String luaCode, String eventAd) throws IOException {
        if (this.l_room != null) {
            this.closeLua();
        }
        this.l_room = new L_Room(this, false);
        this.l_room.developer = "an";
        this.isMinigame = true;
        this.l_room.eventAd = eventAd;
        LUA_THREAD t = new LUA_THREAD2(this.l_room, luaCode);
        t.start();
        this.server.threads.add(t);
        for (PlayerConnection pc : this.clients.values()) {
            pc.LuaGame();
        }
        this.l_room.t = t;

    }

    public void closeLua() {
        L_Room lr = this.l_room;
        if (lr != null) {
            iptal(lr.snowTimer);
            lr.set_interrupted(true);
            if (lr.t != null)
                lr.t.events.clear();
        }
        if (this.playerCount() > 0 & lr != null) {
            Integer[] array = lr.img_list.toArray(new Integer[0]);
            for (Integer img : array) {
                lr.removeImage(img, "");
            }

            array = lr.text_list.toArray(new Integer[0]);
            for (Integer text : array) {
                lr.removeTextArea(text, "");
            }
        }

        runningTimers.forEach((k, v) -> v.cancel(true));
        runningTimers.clear();
        try {
            lr.t.l_room = null;
            lr.t = null;
        } catch (Exception e) {
        }
        /*
         * if (this.l_room.t instanceof LUA_THREAD2) { try { this.NewRound(); }
         * catch (IOException ex) {
         * Logger.getLogger(Room.class.getName()).log(Level.SEVERE, null, ex); }
         * }
         */
        this.autoShaman = true;
        this.autoNewGame = true;
        this.ShamanSkills = true;
        this.AutoTimeLeft = true;
        this.autoKillAfk = true;
        try {
            lr.room = null;
        } catch (Exception e) {
        }
        this.l_room = null;

    }

    public void sendRemoveShamanSkillCode(int skillCode) {
        ByteBuf packet = MFServer.getBuf().writeByte(5).writeByte(40).writeByte(skillCode).writeByte(1);
        for (PlayerConnection client : this.clients.values()) {
            if (client.isShaman) {
                client.sendPacket(packet.retainedSlice());
            }
        }
        packet.release();
    }

    public void resetRoom() {
        this.arrComp.clear();
        this.isDoubleMap = false;
        this.T_20sec = false;
        this.ObjectID.set(0);
        this.anchors.clear();
        iptal(T_newRound);
        iptal(T_Respawn);
        iptal(T_zamanAt);
        iptal(T_Afk);
        iptal(startMapTimer);
        iptal(T_Vampire);
        this.currentShamanCode = 0;
        this.currentShamanCode2 = 0;
        currentJoints.clear();
        currentPhysicObjects.clear();
        objectList.clear();
        iceCubeCount = 0;
        PlayerConnection s1 = getFirstShaman();
        PlayerConnection s2 = getSecondShaman();
        if (s1 != null)
            s1.score = this.Saves[1];
        if (s2 != null)
            s2.score = this.Saves[2];
        this.Saves = new int[3];
        sonKral = null;
        allShamanSkills.clear();
        /*
         * if (shamanSkillsData != null) { for (ByteBuf buf : shamanSkillsData)
         * { if (buf.refCnt() != 0) { buf.release(); } } shamanSkillsData =
         * null; }
         */

        codes = new PlayerConnection[2];
        this.numCompleted.set(0);
        this.holeCoordinate.clear();
        this.cheeseCoordinate.clear();
        this.lastHandyMouseID = null;
        this.lastHandyMouseByte = null;
        this.cloudId = -1;
        this.mapisReady.set(0);
    }

    public map chooseMap() {
        int uniq = this.unique_playerCount();
        if (this.NextPerm != null) {
            int perm = this.NextPerm;
            this.NextPerm = null;
            return this.server.getPerm(perm);
        }
        if (this.NextMap != null) {
            map nm = this.NextMap;
            this.NextMap = null;
            return nm;
        }
        if (this.isVanilla) {
            return VanillaMap.get(MAP_LIST[this.server.random.nextInt(MAP_LIST.length)]);
        } else if (this.isEditeur) {
            map m = new map();
            m.xml = editeurXML;
            m.id = editeurID;
            m.perm = editeurPerm;
            m.name = editeurName;
            return m;
        } else if (this.isTribeHouse) {
            try {
                if (tribe != null && tribe.kabile != null) {
                    int tmap = tribe.kabile.harita;
                    return Harita.al(tmap);
                }

            } catch (Exception e) {
                e.printStackTrace();
                //MFServer.log.warning(MFServer.stackTraceToString(e));

            }
            return VanillaMap.get(0);
        } else if (this.isTutorial) {

            return VanillaMap.get(900);
        } else if (this.isTotemEditeur) {
            return VanillaMap.get(444);
        } else if (this.isNormal && this.Round % 5 == 0) {
            return VanillaMap.get(MAP_LIST[this.server.random.nextInt(MAP_LIST.length)]);
        } else {
            int[] permlist = new int[]{1};
            if (this.isBootcamp) {
                permlist = P_Bootcamp;
            } else if (this.isDefilante) {
                permlist = P_Defilante;
            } else if (this.isMusic) {
                permlist = P_Music;
            } else if (this.isLama) {
                permlist = P_Music;
            } else if (this.isRacing) {
                permlist = P_Racing;
            } else if (this.isSurvivor || this.isKutier) {
                permlist = P_Survivor;
            } else {
                permlist = P_Norm;
            }
            if (this.isMulodrome && this.mulodromeStart) permlist = P_Racing;
            // int perm = permlist[this.server.random.nextInt(permlist.length)];
            if (this.isRacing && this.isLeveTest) {
                if (MFServer.timestamp() - this.leveTestTime > 600) {
                    this.isLeveTest = false;
                    ByteBuf data = null;
                    try {
                        data = MFServer.pack_message("<R>Leve test has been disabled.");

                        for (PlayerConnection pc : this.clients.values()) {
                            if (pc.kullanici.yetki >= 5) {
                                pc.sendPacket(data.retainedSlice());
                            }
                        }
                    } catch (Exception e) {
                        MFServer.log.warning(MFServer.stackTraceToString(e));
                    }
                    MFServer.bitti(data);
                }
                    ArrayList<Integer> arrayList = new ArrayList(MFServer.leveMaps.values());
                    int Rmap = arrayList.get(this.server.random.nextInt(arrayList.size()));

                    try {
                        ByteBuf data = MFServer.pack_message("<VP>LEVE TEST");
                        for (PlayerConnection pc : this.clients.values()) {
                            if (pc.kullanici.yetki >= 5) {
                                pc.sendPacket(data.retainedSlice());
                            }
                        }
                        data.release();
                    } catch (Exception ex) {
                        MFServer.log.warning(MFServer.stackTraceToString(ex));

                    }
                    return Harita.al(Rmap);

            }
            else if(this.isRacing && this.isAgil){
                if (MFServer.timestamp() - this.leveTestTime > 600) {
                    this.isAgil=false;
                }

                int Rmap = MFServer.agilMaps.get(this.server.random.nextInt(MFServer.agilMaps.size()));
                return Harita.alRacing(Rmap);
            }
            else if(this.isRacing && this.isHiddenWater){

                if (MFServer.timestamp() - this.leveTestTime > 600) {
                    this.isHiddenWater=false;
                }
                int Rmap = MFServer.hiddenWaterMaps.get(this.server.random.nextInt(MFServer.hiddenWaterMaps.size()));
                return Harita.alRacing(Rmap);
            }
            return this.server.getPerms(permlist);

        }
    }

    public void addConjuration(int x, int y, int time) throws IOException {
        this.sendAllOld(4, 14, new Object[]{x, y});
        MFServer.executor.schedule(() -> {
            try {
                this.removeConjuration(this.Round, x, y);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }, time, TimeUnit.SECONDS);

    }

    public ArrayList<ByteBuf> sendShamanSkills() {
        ArrayList<ByteBuf> byteBuf = new ArrayList<>();
        if (this.allShamanSkills != null && !this.allShamanSkills.isEmpty()) {

            for (java.util.Map.Entry<String, Integer> entry : this.allShamanSkills.entrySet()) {
                Integer skillCode = Integer.valueOf(entry.getKey());
                Integer skillCount = entry.getValue();
                if (this.isSurvivor & MFServer.forbidden_survivor.contains(skillCode)) {
                    continue;
                }
                if (MFServer.snormal.contains(skillCode)) {
                    if (MFServer.smult.contains(skillCode)) {
                        byteBuf.add(this.sendShamanSkillCode(skillCode, 1));
                    } else if (skillCode.equals(81)) {
                        byteBuf.add(this.sendShamanSkillCode(skillCode, skillCount));
                    } else {

                        byteBuf.add(this.sendShamanSkillCode(skillCode, skillCount));
                    }
                } else if (MFServer.sfull.contains(skillCode)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100));
                } else if (skillCode.equals(1) || skillCode.equals(45)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100 + skillCount * 10));
                } else if (skillCode.equals(2)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100 + skillCount * 4));
                } else if (skillCode.equals(22) || skillCode.equals(72)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 20 + skillCount * 5));
                } else if (skillCode.equals(10) || skillCode.equals(13)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 3));
                } else if (skillCode.equals(12)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, skillCount * 4));
                } else if (skillCode.equals(20)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 110 + skillCount * 4));
                } else if (skillCode.equals(23)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100 - skillCount * 10));
                } else if (skillCode.equals(28) || skillCode.equals(65) || skillCode.equals(74)
                        || skillCode.equals(85)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, skillCount * 2));
                } else if (skillCode.equals(32)) {
                    this.iceCubeCount += skillCount;
                } else if (skillCode.equals(40)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100 + skillCount * 8));
                } else if (skillCode.equals(42) || skillCode.equals(43)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 250 - skillCount * 10));
                } else if (skillCode.equals(49)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 96 - skillCount * 6));
                } else if (skillCode.equals(54)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 130));
                } else if (skillCode.equals(68)) {
                    byteBuf.add(this.sendShamanSkillCode(skillCode, 100 - skillCount * 4));
                } else {
                    if (!skillCode.equals(89)) {
                        continue;
                    }
                    byteBuf.add(this.sendShamanSkillCode(54, 100 - skillCount * 4));
                    byteBuf.add(this.sendShamanSkillCode(49, 100 - skillCount * 4));
                }
            }
        }
        return byteBuf;
    }

    public ByteBuf sendShamanSkillCode(int skillCode, int skillId) {

        return MFServer.getBuf().writeByte(8).writeByte(10).writeByte(skillCode).writeByte(skillId);
    }

    public void removeConjuration(int round, int x, int y) throws IOException {
        if (round == this.Round) {
            this.sendAllOld(4, 15, new Object[]{x, y});
        }

    }

    public ArrayList<PlayerConnection> findNearMices(int pcode, int x, int y) {
        ArrayList<PlayerConnection> list = new ArrayList<>();
        for (PlayerConnection client : this.clients.values()) {
            if (x - 65 <= client.x && client.x <= x + 65 && client.y >= y - 65 && client.y <= y + 65 && !client.isDead
                    && client.kullanici != null && client.kullanici.code != pcode) {
                list.add(client);
            }
        }
        return list;
    }

    public void NewRound() {
        // this.lock.isLocked();
        Long tt = System.currentTimeMillis();
        ScheduledExecutorService[] exc = new ScheduledExecutorService[]{MFServer.RoomExecutor};
        if (this.isofficial) exc[0] = MFServer.RoomExecutorOfficial;
        if (this.lock4.getQueueLength() > 3) return;
        exc[0].execute(() -> {
           /* if(isEditeur){

                try {
                    sendAll(MFServer.pack_old(14, 14, new Object[]{""}));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }*/
            if (this.isEditeur && !this.workEditeur) return;
            this.lock4.lock();

            //<C><P /><Z><S><S X="493" L="163" Y="383" H="10" P="0,0,0.3,0.2,0,0,0,0" T="0" /></S><D><DS X="484" Y="361" /></D><O /></Z></C>
            // if (this.isEditeur && !this.workEditeur) return;
            try {
                if ((this.Round++) % 10 == 10) {
                    if (this.isMulodrome) {
                        this.isMulodrome = false;
                        this.mulodrome.clear();
                        this.mulodromeStart = false;
                        this.sendAll(this.mulodromeIptal());
                    }
                }
                if (this.Round == 100) {
                    this.Round = PlayerConnection.betweenRandom(1, 7) * 10;
                }
                this.Started = -1;
                int count = this.unique_playerCount();
                this.odaBaslangic = count;
               /* this.motor=true;
                this.daires =new HashSet<>();
                this.daires.add(new Daire(1, 232, 338,15,"78f4622cedf011e7b5f688d7f643024a.png"));*/
                if (count == 0)
                    return;

                try {
                    if (this.event) {
                        this.event = false;
                        try {
                            this.closeLua();
                        } catch (Exception e) {

                        }
                        this.isMinigame = false;
                    }
                    //     Date date = new Date();
                    //  LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    //  int ay = localDate.getMonth().getValue();

                    if (this.l_room != null && this.l_room.developer.equals("an")) this.event = true;
                    else if ((this.Round % 15 == 0 && this.isofficial && (this.isNormal || this.isVanilla || this.isSurvivor) && count >= 7)) {

                        //Date date = new Date();
                        // LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        //int gun = localDate.getDayOfMonth();
                        String ln = "dragon.lua";
                        String code = new String(Files.readAllBytes(Paths.get("data/" + ln)), StandardCharsets.UTF_8);
                        if (!code.isEmpty()) {

                            this.runEvent(code, "mg9");

                            return;
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                if ((this.isRacing || this.isBootcamp) && this.forceAyna != 0) {
                    if (this.server.random.nextInt(4) == 2) {
                        ayna = this.server.random.nextBoolean();
                    }
                }
                if (this.forceAyna != 0) {
                    this.ayna = this.forceAyna == 1;
                    this.forceAyna = 0;
                }
                if (count > 3) {
                    for (java.util.Map.Entry<String, PlayerConnection> us : clients.entrySet()) {
                        PlayerConnection client = us.getValue();
                        Kullanici kullanici = client.kullanici;
                        if (kullanici == null) {
                            clients.remove(us.getKey());
                            continue;
                        }
                        if (kullanici.code == this.currentShamanCode) {
                            chech_shaman_feather(client, this.Saves[1]);
                        }
                        if (kullanici.code == this.currentShamanCode2) {
                            chech_shaman_feather(client, this.Saves[2]);
                        }
                        kullanici.tur += 1;
                        if (!this.isFuncorp && !this.isMinigame && !this.isTribeHouse && !this.isEditeur && !this.isTotemEditeur && !this.isTutorial) {
                            client.gorevIlerleme(5, this.orjroundTime);
                        }
                    }
                }
                if ((this.isSurvivor || this.isRacing || this.isKutier) & this.countStats) {
                    for (java.util.Map.Entry<String, PlayerConnection> us : clients.entrySet()) {
                        PlayerConnection client = us.getValue();
                        Kullanici kullanici = client.kullanici;
                        if (kullanici == null) {
                            clients.remove(us.getKey());
                            continue;
                        }
                        if (!client.isNew & !client.isAfk) {
                            if (count > 3) {

                                try {
                                    if (this.isRacing) {
                                        if (client.isComp) {

                                            kullanici.extraStats.racing_comp_rounds += 1;
                                            client.addInventoryItem(2254, 1);
                                        }

                                        kullanici.extraStats.racing_rounds += 1;
                                        client.checkAndRebuildTitleList("racing");
                                    } else {

                                        kullanici.extraStats.survivor_rounds += 1;
                                        if (client.isShaman) {
                                            kullanici.extraStats.survivor_shaman += 1;
                                            int killed = 0;
                                            for (PlayerConnection cl : clients.values()) {
                                                if (cl.isDead & !cl.isAfk & !cl.isNew & !cl.isShaman)
                                                    killed++;
                                            }
                                            if (killed > 0) {
                                                client.addInventoryItem(2260, Math.min(killed, 10));
                                                if (this.isKutier) {
                                                    client.kullanici.extraStats.kutier_killed += killed;
                                                    client.gorevIlerleme(10, killed);
                                                }
                                                client.gorevIlerleme(11, killed);
                                                kullanici.extraStats.survivor_killed += killed;
                                            }

                                        }
                                        if (!client.isDead && !client.isShaman && !client.isVampire) {
                                            if (this.isKutier) {
                                                kullanici.extraStats.kutier_survivor += 1;
                                                client.gorevIlerleme(4, 1);
                                                //client.log.put("kutier_survivor", client.log.get("kutier_survivor") + 1);
                                            } else {
                                                client.gorevIlerleme(3, 1);
                                            }
                                            kullanici.extraStats.survivor += 1;
                                            //  client.log.put("survivor", client.log.get("survivor") + 1);
                                            client.score += 10;
                                            kullanici.peynir += 272;
                                        }

                                        client.checkAndRebuildTitleList("survivor");
                                        client.checkAndRebuildTitleList("kutier");
                                    }
                                } catch (Exception e) {
                                    MFServer.log.warning(MFServer.stackTraceToString(e));
                                }

                            }
                        } else {
                            client.isNew = false;
                        }

                    }
                }
                try {
                    this.resetRoom();


                } catch (Exception e) {
                    MFServer.log.warning(MFServer.stackTraceToString(e));
                }
                try {
                    this.setSyncer();
                    for (PlayerConnection client : clients.values()) {
                        client.resetPlay();
                    }


                } catch (Exception e) {
                    MFServer.log.warning(MFServer.stackTraceToString(e));
                }

                this.roundTime = this.orjroundTime;
                int time = this.getRoundTime();
                // for(StackTraceElement c :

                map m = this.chooseMap();

                if (forcePerm != -1) {
                    m.perm = forcePerm;
                    forcePerm = -1;
                }
                this.Map = m;
                if (this.Map.perm == 8 || MFServer.doubleMaps.contains(this.Map.id) || this.Map.perm == 32)
                    this.isDoubleMap = true;
                try {
                    if (this.autoShaman) {
                        this.HazirlaSaman();
                    }
                } catch (Exception e) {
                    MFServer.log.warning(MFServer.stackTraceToString(e));
                }

                // this.sendAll(new MapData(this).data());
                // this.sendAll(new MapData(this, Map).data());
                ByteBuf dat = new MapData(this, Map).data();
                this.sendAll(dat);
                T_zamanAt = exc[0].schedule(() -> {
                    try {
                        ByteBuf dat2 = new RoundTime(this, time).data();

                        this.sendAll(dat2);
                        for (PlayerConnection pc : codes) {
                            if (pc != null && pc.kullanici != null && pc.kullanici.beceriler.containsKey("67")) {
                                pc.room.sendAll(MFServer.getBuf().writeByte(5).writeByte(48).writeByte(0).writeInt(pc.kullanici.code));
                            }
                        }
                    } catch (Exception e) {

                        MFServer.log.warning(MFServer.stackTraceToString(e));
                    }
                }, 700, TimeUnit.MILLISECONDS);
                //  this.sendAll(MFServer.getBuf().writeBytes(this.server.hexStringToByteArray("050200000330001d5c000001b77801ad96c14e834010865f65b36729ccee4221b25cda430f1a9be841bd34354513d3d2261aad6fef0c210d2cb366631bda4226e5e3ff676667296755b914b3b59552ccefadfcb9d699c24b2b8fabfaab6eea5ddd7c7ec4c7d5ebbed92cd6dbedfebbae9bdbf5414dde0f6f52c455f95c95f7f8114f56ea2291e2c14a40c4d2cae40a8f89c6afa22b3aa4b8b1324ff0bca7bfbd6c0a23c58e9efe68a5a1f8c24a95b6e016a928c623a3a20f6d6f66a01174503ca15a2fb4551986cc39a4069fcebeca0c553022d5b4354edc9346e5050e556a1e99e1ed98cb4b2221d50c136321f5f1c8549ab37e1e536becbf91778c9da15317f9c599a6606a14d647295ff414c6d9840263bc731dd09a261b1b074ac6ff913ae190d93948a0f6724a0e05ce115e6514e23cc7d134427a8d072115b32affa84f10d3d0a07075026ae7adf74b0ebe36a22674902aac3173be3181e6bc4ba4040f452a54e76c166078e25477c36838e1bcabdc0c8cd34dcc1c9e9ace781fda6669a893dbd5c0cbecd6a4c2679ea67b58363ddb85ce70b138d904f0767bdfb9a6cd9571ae0cc61d6434aa0fe73bf714c8d9cd637c499893ff3bfa89f1ad219e55bf43d8b95c000e5f4261722048616c6c6f7765656e5700")));

                /*
                 * if (shamanSkillsData != null) { for (ByteBuf buf :
                 * this.shamanSkillsData) {
                 *
                 * this.sendAll(buf.retainedSlice()); } }
                 */

                //this.sendAll(MFServer.getBuf().writeByte(100).writeByte(6).writeShort(0));
                // this.sendAll(MFServer.getBuf().writeByte(60).writeByte(4).writeShort(1));
                for (PlayerConnection client : this.clients.values()) {

                    if (this.isBootcamp || this.isDefilante || this.playerCount() < 2) {
                        client.sendStartMap(false);
                    } else {
                        client.sendStartMap(true);
                    }
                    if (client.isShaman && !this.isEditeur && this.ShamanSkills && !isKutier) {
                        try {

                            Beceriler.Yolla(client, false);
                        } catch (Exception e) {
                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    }
                    if (client.hidden) client.isDead = true;
                    try {

                        if (this.isMulodrome && this.mulodromeStart && !this.mulodrome.containsKey(client.kullanici.code))
                            client.isDead = true;
                    } catch (Exception e) {
                        MFServer.log.warning(MFServer.stackTraceToString(e));
                    }
                }

                this.sendAll(getPlayerBuf());

                if (!this.isBootcamp && !this.isDefilante && this.clients.size() >= 2 & !this.isEditeur) {
                    this.startMapTimer = exc[0].schedule(() -> {
                        for (PlayerConnection client : this.clients.values()) {
                            client.sendStartMap(false);
                        }
                    }, 3, TimeUnit.SECONDS);
                }
                try {
                    this.sendAll(new Shaman(this).data());

                    this.sendSync();

                } catch (Exception e) {
                    MFServer.log.warning(MFServer.stackTraceToString(e));
                }

                this.Started = System.currentTimeMillis();
                this.changedTime = System.currentTimeMillis();
                if (this.clients.size() == 0) return;
                if (this.autoNewGame) {

                    this.T_newRound = exc[0].schedule(() -> {
                        try {
                            this.NewRound();
                        } catch (Exception e) {
                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    }, time, TimeUnit.SECONDS);
                    if (this.autoRespawn) {
                        this.T_Respawn = exc[0].schedule(() -> {
                            try {
                                this.respawn_players();
                            } catch (Exception e) {
                                MFServer.log.warning(MFServer.stackTraceToString(e));
                            }
                        }, 5, TimeUnit.SECONDS);
                    }
                }
                if (this.autoKillAfk) {
                    this.T_Afk = exc[0].schedule(() -> {
                        try {
                            this.kill_afk_players();
                        } catch (Exception e) {

                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    }, 30, TimeUnit.SECONDS);
                }
                if (this.isRacing) {
                    this.sendAll(MFServer.getBuf().writeByte(5).writeByte(1).writeByte(this.Round % 10 - 1)
                            .writeInt(this.get_highest()));
                }
                if (this.Map.perm == 11) {

                    T_Vampire = exc[0].schedule(() -> {
                        VampireCode = this.get_highest();
                        PlayerConnection pc = this.clients_p.get(VampireCode);
                        if (pc != null) {
                            try {
                                this.setVampirePlayer(pc.kullanici.isim);
                            } catch (Exception e) {

                                MFServer.log.warning(MFServer.stackTraceToString(e));
                            }
                        }
                    }, 10, TimeUnit.SECONDS);

                }

                boolean transformed = false;


                if (this.Map.perm.equals(0) || this.Map.perm.equals(2)) {
                    if (M_catchcheese.contains(this.Map.id)) {
                        this.sendAllOld(8, 23, new Object[]{this.currentShamanCode});
                        this.sendAllOld(5, 19, new Object[]{this.currentShamanCode});
                    } else if (M_catchcheese_nosham.contains(this.Map.id)) {
                        this.sendAllOld(8, 23, new Object[]{this.currentShamanCode});
                        this.sendAllOld(5, 19, new Object[]{this.currentShamanCode});
                        this.sendAllOld(8, 20, new Object[]{this.currentShamanCode});

                    } else if (this.Map.id >= 200 && this.Map.id <= 211) {
                        transformed = true;
                    }
                }
                if (this.Map.perm == 14) {
                    transformed = true;
                }
                for (PlayerConnection pc : this.clients.values()) {
                    try {

                        pc.send_isim_renk();
                        pc.startPlay(false);
                        if (transformed)
                            pc.giveTransformice();
                    } catch (Exception e) {
                        MFServer.log.warning(MFServer.stackTraceToString(e));
                    }


                }

                // System.out.println((this.mevcutVeri.harita == this.Map.id)+" "+this.mevcutVeri.harita+" "+this.Map.id);
                if (this.isTengri && this.mevcutVeri != null && this.mevcutHid != -1 && this.mevcutVeri.harita == this.Map.id) {
                    //  ByteBuf data = new NewPlayer("(Tengri)" + this.mevcutVeri.ad + "#" + TENGRI_DATA).data();

                    //   this.sendAll(data);
                    int r = this.Round;
                    int ttt = (int) (this.mevcutVeri.delik / 10);
                    int i = 0;
                    MFServer.TengriExecutor.schedule(() -> {
                        //   System.out.println(r+" "+this.Round+" R");
                        if (r != this.Round) return;
                        ByteBuf bf = MFServer.getBuf();
                        try {
                            bf.writeByte(8).writeByte(6).writeByte(0).writeInt(7).writeShort(777).writeByte(1).writeShort(ttt);
                            this.sendAll(bf);

                        } catch (Exception e) {
                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    }, this.mevcutVeri.delik, TimeUnit.MILLISECONDS);
                    MFServer.TengriExecutor.schedule(() -> {
                        //   System.out.println(r+" "+this.Round+" R");
                        if (r != this.Round) return;
                        try {
                            this.sendAll(new GetCheese(7).data());

                        } catch (Exception e) {

                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    }, this.mevcutVeri.pey, TimeUnit.MILLISECONDS);
                    long Tping = 0;
                    for (byte[] bytes : this.mevcutVeri.arrs) {
                        Tping += this.mevcutVeri.pingler.get(i);
                        int I = i;
                        long tping = Tping;
                        if (i % 5 == 0) {
                            Tping = 0;
                        }
                        MFServer.TengriExecutor.schedule(() -> {
                            //   System.out.println(r+" "+this.Round+" R");
                            if (r != this.Round) return;
                            ByteBuf bf = MFServer.getBuf();
                            try {
                                bf.writeByte(4);
                                bf.writeByte(4);

                                bf.writeInt(7);
                                bf.writeInt(r);
                                bf.writeBytes(bytes);
                                //     bf.writeBytes(bytes,0,11);

                                this.sendAll(bf);
                                if (I % 5 == 0 && tping != 0) {
                                    sendMessage("Average ping is " + (tping / 5) + "ms");

                                }

                            } catch (Exception e) {
                                MFServer.log.warning(MFServer.stackTraceToString(e));
                            }
                        }, this.mevcutVeri.vakitler.get(i), TimeUnit.MILLISECONDS);
                        i++;
                    }

                    this.mevcutVeri = null;
                    this.mevcutHid = 0L;
                }
                if (this.isTotemEditeur) {
                    for (PlayerConnection cl : this.clients.values()) {
                        if (cl.kullanici != null) cl.sendTotem(400, 200);
                    }
                }
                if ((this.isRacing || this.isBootcamp || this.isDefilante) && !this.isFuncorp && this.password.isEmpty()) {

                    Integer id = this.Map.id;
                    Integer isLev = MFServer.leveMaps2.get(id);
                    if (isLev != null) {
                        id = isLev;
                    }
                    MFServer.rekorAl(id, (Rekor rekor) -> {
                        try {
                            if (rekor != null) {
                                iletiYolla("record", rekor.ad, rekor.sure);
                            }
                            this.tacYolla();
                        } catch (Exception e) {

                            MFServer.log.warning(MFServer.stackTraceToString(e));
                        }
                    });

                }
                this.mapisReady.set(1);

                if (this.l_room != null) {
                    this.l_room.eventNewGame();
                }
                if ((!password.isEmpty()) && countStats) {
                    for (PlayerConnection playerConnection : clients.values()) {
                        if (PlayerConnection.isVPN(playerConnection.ip) && System.currentTimeMillis() - playerConnection.lastVPNSent > 1_000 * 60 * 30) {
                            playerConnection.lastVPNSent = System.currentTimeMillis();
                            playerConnection.sendChatServer("<R>WARNING " + playerConnection.kullanici.isim + " is probably using Proxy/VPN");
                        }
                    }
                }
                if (isEditeur) {

                    sendAll(MFServer.pack_old(14, 14, new Object[]{""}));
                }


            } catch (Exception e) {

                MFServer.log.warning(MFServer.stackTraceToString(e));

                // String name = "";
                // MFServer.log.warning("[" + this.name + "]" + MFServer.stackTraceToString(e));

            } finally {

                this.lock4.unlock();
            }

        });

    }

    public void iletiYolla(String anahtar, Object... args) throws IOException {
        for (PlayerConnection pc : clients.values()) {
            pc.iletiYolla(anahtar, args);
        }
    }

    public void setVampirePlayer(String playerName) throws IOException {
        if (playerName != null) {
            PlayerConnection client = this.clients.get(playerName);
            if (client != null && client.kullanici != null) {
                client.isVampire = true;
                ByteBuf packet = MFServer.getBuf().writeByte(8).writeByte(66).writeInt(client.kullanici.code);
                this.sendAll(packet);

                if (this.l_room != null) {
                    this.l_room.eventPlayerVampire(playerName);

                }
            }
        }
    }


    public void setVampirePlayer(int pCode) throws IOException {
        ByteBuf packet = MFServer.getBuf().writeByte(8).writeByte(66).writeInt(pCode);
        this.sendAll(packet);
        PlayerConnection client = this.clients_p.get(pCode);
        if (client != null && client.kullanici != null) {
            client.isVampire = true;


            if (this.l_room != null) {
                this.l_room.eventPlayerVampire(client.kullanici.isim);


            }
        }
    }

    public void respawn_players() throws IOException {
        for (PlayerConnection client : this.clients.values()) {
            if (client.isDead && client.kullanici != null) {
                this.respawn_player(client);
            }
        }

        iptal(T_Respawn);
        this.T_Respawn = MFServer.RoomExecutor.schedule(() -> {
            try {
                this.respawn_players();
            } catch (Exception e) {
                MFServer.log.warning(MFServer.stackTraceToString(e));
            }
        }, 5, TimeUnit.SECONDS);
    }

    public void respawn_player(PlayerConnection client) throws IOException {
        if (!client.hidden) {
            client.isDead = false;
            client.hasCheese = false;
            client.playerStartTime = System.currentTimeMillis();
            ByteBufOutputStream bfs = MFServer.getStream();
            bfs.writeShort(36866);

            client.writePlayerData(bfs);
            bfs.writeByte(0);
            bfs.writeByte(0);
            //dat = new PlayerList(this).data();
            this.sendAll(bfs.buffer());
            if (this.isBootcamp) {
                //   ByteBuf data = new NewPlayer(client, client.getPlayerData(), 0).data();
                // addtoBuffer(data,client.kullanici.code);
                // this.sendAll(data);
                if (client == this.sonKral) tacYolla();
                if (this.countStats && (this.isDefilante || this.isRacing || this.isBootcamp)) {
                    client.sistem = new Sistem();
                    byte[] bf = client.sistem.arrayList.get(0);
                    Sistem.writeBoolean(ayna, 24, bf);
                    Sistem.writeLong(System.currentTimeMillis(), 0, client.sistem.arrayList.get(0));

                }

                // client.koordinatProtos.clearKoordinatlar();
                //  client.koordinatProtos.setStart(client.playerStartTime);
                //  client.coordinates.setLength(0);
            } else {
                // this.sendAll(new NewPlayer(client, client.getPlayerData(), 1).data());
            }

        }
    }


    public void sendAll(ByteBuf packet) throws IOException {
        //this.lastMapTime=System.currentTimeMillis();
        // packet.retain();
        for (PlayerConnection client : clients.values()) {
            client.sendPacket(packet.retainedSlice());
        }
        // packet.release();
        if (packet.refCnt() > 0) packet.release();
    }

    public void sendAllOthers(ByteBuf packet, int code) throws IOException {

        // packet.retain();
        for (PlayerConnection client : clients.values()) {
            if (client.kullanici != null && client.kullanici.code != code) {
                client.sendPacket(packet.retainedSlice());
            }
        }

        packet.release();
    }

    public void sendAllOldOthers(int Token1, int Token2, Object[] values, int code) throws IOException {
        ByteBuf packet = MFServer.pack_old(Token1, Token2, values);
        // packet.retain();
        for (PlayerConnection client : clients.values()) {
            if (client.kullanici != null && client.kullanici.code != code) {
                client.sendPacket(packet.retainedSlice());
            }
        }

        packet.release();
    }

    public void sendStopPlayer(int playerCode, boolean activate) throws IOException {
        this.sendAll(MFServer.getBuf().writeByte(5).writeByte(34).writeInt(playerCode).writeBoolean(activate));
    }

    public void sendAllOld(int Token1, int Token2, Object[] values) throws IOException {
        ByteBuf packet = MFServer.pack_old(Token1, Token2, values);
        // packet.retain();
        //  System.out.println(MFServer.bytesToHex(packet.copy()));
        for (PlayerConnection client : clients.values()) {
            client.sendPacket(packet.retainedSlice());

        }

        packet.release();
    }

    public void removeAllObjects() throws IOException {
        this.sendAll(MFServer.getBuf().writeByte(5).writeByte(32));
        this.anchors.clear();
        // this.objectList.clear();
    }

    public void addBoost(int x, int y, final int i, int angle) throws IOException {
        this.sendAll(MFServer.getBuf().writeByte(5).writeByte(14).writeShort(x).writeShort(y).writeByte(i)
                .writeShort(angle));
    }

    public void addJoint(int id, int physicObject1, int physicObject2, LuaTable jointDef) {

        try {
            ByteBufOutputStream p = MFServer.getStream();
            p.writeByte(29);
            p.writeByte(30);

            if (id > 32767) {
                id = 32767;
            }
            if (physicObject1 > 32767) {
                physicObject1 = 32767;
            }
            if (physicObject2 > 32767) {
                physicObject2 = 32767;
            }

            p.writeShort(id);
            p.writeShort(physicObject1);
            p.writeShort(physicObject2);
            int type = 0;
            try {
                type = jointDef.get("type").checkint();
                if (type > 3) {
                    type = 0;
                }
            } catch (LuaError ex) {

            }
            p.writeByte(type);
            try {
                String p1xy = jointDef.get("point1").checkjstring();
                p.writeBoolean(true);
                if (p1xy.contains(",")) {
                    String[] x = StringUtils.split(p1xy, ",");
                    if (StringUtils.isNumeric(x[0]) && StringUtils.isNumeric(x[1])) {
                        p.writeShort(Integer.valueOf(x[0]));
                        p.writeShort(Integer.valueOf(x[1]));
                    } else {
                        p.writeInt(0);
                    }
                } else {
                    p.writeInt(0);
                }
            } catch (LuaError ex) {
                p.writeBoolean(false);
                p.writeInt(0);
            }

            try {
                String p2xy = jointDef.get("point2").checkjstring();
                p.writeBoolean(true);
                if (p2xy.contains(",")) {
                    String[] x = StringUtils.split(p2xy, ",");
                    if (StringUtils.isNumeric(x[0]) && StringUtils.isNumeric(x[1])) {
                        p.writeShort(Integer.valueOf(x[0]));
                        p.writeShort(Integer.valueOf(x[1]));
                    } else {
                        p.writeInt(0);
                    }
                } else {
                    p.writeInt(0);
                }
            } catch (LuaError ex) {
                p.writeBoolean(false);
                p.writeInt(0);
            }

            try {
                String p3xy = jointDef.get("point3").checkjstring();
                p.writeBoolean(true);
                if (p3xy.contains(",")) {
                    String[] x = StringUtils.split(p3xy, ",");
                    if (StringUtils.isNumeric(x[0]) && StringUtils.isNumeric(x[1])) {
                        p.writeShort(Integer.valueOf(x[0]));
                        p.writeShort(Integer.valueOf(x[1]));
                    } else {
                        p.writeInt(0);
                    }
                } else {
                    p.writeInt(0);
                }
            } catch (LuaError ex) {
                p.writeBoolean(false);
                p.writeInt(0);
            }
            p.writeBoolean(false);
            p.writeInt(0);

            int frequency = 0;
            try {
                frequency = MFServer.parseLuaFloat(jointDef.get("frequency").toString());
                if (frequency > 1032) {
                    frequency = 1032;
                }
            } catch (LuaError ex) {

            }
            p.writeShort(frequency);
            int damping = 0;
            try {
                damping = MFServer.parseLuaFloat(("damping").toString());
                if (damping > 1032) {
                    damping = 1032;
                }
            } catch (LuaError ex) {

            }
            p.writeShort(damping);

            int line = 0;
            try {
                line = MFServer.parseLuaFloat(("line").toString());
                if (line > 1032) {
                    line = 1032;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(line);

            int color = 0;
            try {
                color = jointDef.get("color").checkint();

                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeInt(color);

            int alpha = 100;
            try {
                alpha = MFServer.parseLuaFloat(jointDef.get("alpha").toString());
                if (alpha > 1032) {
                    alpha = 1032;
                }
            } catch (LuaError ex) {

            }
            p.writeShort(alpha);

            boolean foreground = false;
            try {
                foreground = jointDef.get("foreground").toboolean();

            } catch (LuaError ex) {

            }

            p.writeBoolean(foreground);

            try {
                String axis = jointDef.get("axis").checkjstring();

                if (axis.contains(",")) {
                    String[] x = StringUtils.split(axis, ",");
                    if (StringUtils.isNumeric(x[0]) && StringUtils.isNumeric(x[1])) {
                        p.writeShort(Integer.valueOf(x[0]));
                        p.writeShort(Integer.valueOf(x[1]));
                    } else {
                        p.writeInt(0);
                    }
                } else {
                    p.writeInt(0);
                }
            } catch (LuaError ex) {
                p.writeInt(0);
            }

            int angle = 0;
            try {
                angle = jointDef.get("angle").toint();
                if (angle > 32767) {
                    angle = 32767;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(angle);

            int limit1 = 0;
            try {
                limit1 = MFServer.parseLuaFloat(jointDef.get("limit1").toString());
                if (limit1 > 1032) {
                    limit1 = 1032;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(limit1);

            int limit2 = 0;
            try {
                limit2 = MFServer.parseLuaFloat(jointDef.get("limit2").toString());
                if (limit2 > 1032) {
                    limit2 = 1032;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(limit2);

            int forceMotor = 0;
            try {
                forceMotor = MFServer.parseLuaFloat(jointDef.get("forceMotor").toString());
                if (forceMotor > 1032) {
                    forceMotor = 1032;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(forceMotor);

            int speedMotor = 0;
            try {
                speedMotor = MFServer.parseLuaFloat(jointDef.get("speedMotor").toString());
                if (speedMotor > 1032) {
                    speedMotor = 1032;
                }
                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeShort(speedMotor);

            int ratio = 100;
            try {
                ratio = MFServer.parseLuaFloat(jointDef.get("ratio").toString());
                if (ratio > 1032) {
                    ratio = 1032;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(ratio);

            this.sendAll(p.buffer());
            this.currentJoints.add(id);

        } catch (IOException error) {
            error.printStackTrace();
        }
    }

    public void addPhysicObject(int id, int x, int y, LuaTable bodyDef) {

        try {
            ByteBufOutputStream p = MFServer.getStream();
            p.writeByte(29);
            p.writeByte(28);

            if (id > 32767) {
                id = 32767;
            }
            if (x > 32767) {
                x = 32767;
            }
            if (y > 32767) {
                y = 32767;
            }

            p.writeShort(id);
            boolean dynamic = false;
            try {
                dynamic = bodyDef.get("dynamic").toboolean();

            } catch (LuaError ex) {
            }
            p.writeBoolean(dynamic);

            int type = 0;
            try {
                type = bodyDef.get("type").checkint();
                if (type > 127) {
                    type = 127;
                }
            } catch (LuaError ex) {
            }
            p.writeByte(type);

            p.writeShort(x);
            p.writeShort(y);

            int width = 0;
            try {
                width = bodyDef.get("width").checkint();
                if (width > 32767) {
                    width = 32767;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(width);

            int height = 0;
            try {
                height = bodyDef.get("height").checkint();
                if (height > 32767) {
                    height = 32767;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(height);

            boolean foreground = false;
            try {
                foreground = bodyDef.get("foreground").toboolean();

            } catch (LuaError ex) {
            }
            p.writeBoolean(foreground);

            int friction = 0;
            try {
                friction = MFServer.parseLuaFloat(bodyDef.get("friction").toString());
                if (friction > 1032) {
                    friction = 1032;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(friction);

            int restitution = 0;
            try {
                restitution = MFServer.parseLuaFloat(bodyDef.get("restitution").toString());
                if (restitution > 1032) {
                    restitution = 1032;
                }
            } catch (LuaError ignored) {
            }
            p.writeShort(restitution);

            int angle = 0;
            try {
                angle = MFServer.parseLuaFloat(bodyDef.get("angle").toString());
                if (angle > 1032) {
                    angle = 1032;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(angle);

            int color = 0;
            try {
                color = bodyDef.get("color").checkint();

                p.writeBoolean(true);
            } catch (LuaError ex) {
                p.writeBoolean(false);
            }
            p.writeInt(color);

            boolean miceCollision = true;
            try {
                miceCollision = bodyDef.get("miceCollision").toboolean();

            } catch (LuaError ignored) {
            }
            p.writeBoolean(miceCollision);

            boolean groundCollision = true;
            try {
                groundCollision = bodyDef.get("groundCollision").toboolean();

            } catch (LuaError ignored) {
            }
            p.writeBoolean(groundCollision);

            boolean fixedRotation = false;
            try {
                fixedRotation = bodyDef.get("fixedRotation").toboolean();

            } catch (LuaError ex) {
            }
            p.writeBoolean(fixedRotation);

            int mass = 0;
            try {
                mass = bodyDef.get("mass").checkint();
                if (mass > 32767) {
                    mass = 32767;
                }
            } catch (LuaError ignored) {
            }
            p.writeShort(mass);

            int linearDamping = 0;
            try {
                linearDamping = MFServer.parseLuaFloat(bodyDef.get("linearDamping").toString());
                if (linearDamping > 1032) {
                    linearDamping = 1032;
                }
            } catch (LuaError ignored) {
            }
            p.writeShort(linearDamping);

            int angularDamping = 0;
            try {
                angularDamping = MFServer.parseLuaFloat(bodyDef.get("linearDamping").toString());
                if (angularDamping > 1032) {
                    angularDamping = 1032;
                }
            } catch (LuaError ex) {
            }
            p.writeShort(angularDamping);

            p.writeBoolean(false);
            p.writeShort(0);

            this.sendAll(p.buffer());

            this.currentPhysicObjects.add(id);

        } catch (IOException error) {
            error.printStackTrace();
        }
    }

    public void addDefilante(int x, int y, int id) throws IOException {

        this.sendAll(
                MFServer.getBuf().writeByte(5).writeByte(14).writeShort(x).writeShort(y).writeByte(id).writeShort(0));
    }

    public void displayParticle(int i, int x, int y) {
        displayParticle(i, x, y, 0, 0, 0, 0, "");
    }

    public void displayParticle(int particleType, int xPosition, int yPosition, int xSpeed, int ySpeed,
                                int xAcceleration, int yAcceleration, String targetPlayer) {

        try {
            ByteBufOutputStream p = MFServer.getStream();
            p.writeByte(29);
            p.writeByte(27);

            if (particleType > 128) {
                particleType = 128;
            }
            if (xPosition > 32767) {
                xPosition = 32767;
            }
            if (yPosition > 32767) {
                yPosition = 32767;
            }
            if (xSpeed > 1032) {
                xSpeed = 1032;
            }
            if (ySpeed > 1032) {
                ySpeed = 1032;
            }
            if (xAcceleration > 1032) {
                xAcceleration = 1032;
            }
            if (yAcceleration > 1032) {
                yAcceleration = 1032;
            }

            p.writeByte(particleType);
            p.writeShort(xPosition);
            p.writeShort(yPosition);
            p.writeShort(xSpeed);
            p.writeShort(ySpeed);
            p.writeShort(xAcceleration);
            p.writeShort(yAcceleration);

            if (targetPlayer.length() == 0) {
                this.sendAll(p.buffer());
            } else {
                sendTarget(targetPlayer, p.buffer());
            }

        } catch (IOException error) {
            error.printStackTrace();
        }
    }

    void sendTarget(String name, ByteBuf buf) throws IOException {
        PlayerConnection pc = this.clients.get(name);
        if (pc != null) {
            pc.sendPacket(buf);
        }
    }

    public void removeObject(int objectId) throws IOException {

        ByteBufOutputStream p = MFServer.getStream();
        p.writeByte(4);
        p.writeByte(8);
        p.writeInt(objectId);
        p.writeBoolean(true);
        this.objectList.remove(objectId);
        this.sendAll(p.buffer());

    }

    public void setSyncer() {
        if (clients.size() < 1) return;
        try {
            final HashMap<Long, Integer> names = new HashMap<>();
            for (final PlayerConnection client : this.clients.values()) {
                if (client.kullanici == null) continue;
                names.put((client.isAfk) ? 300 : (client.ping), client.kullanici.code);
            }
            if (names.size() == 0) return;
            final SortedSet<Long> keys = new TreeSet<>(names.keySet());
            int found = names.get(keys.first());
            if (clients.containsKey("Tengri")) {
                found = clients.get("Tengri").kullanici.code;
            }
            this.Syncer = found;
        } catch (Exception e) {
            MFServer.log.warning(MFServer.stackTraceToString(e));
        }

    }

    public void sendSync() throws IOException {
        if (clients.size() < 1) return;
        if (this.Syncer != -1) {
            PlayerConnection pc = this.clients_p.get(this.Syncer);
            if (pc != null) {
                pc.isSyncer = true;
            }
            this.sendAllOld(8, 21, new Object[]{this.Syncer, ""});

        }
    }

    public void kraliVer(SRC<PlayerConnection> src) {
        PlayerConnection[] kullanici1 = new PlayerConnection[1];
        final AtomicLong rek = new AtomicLong();
        ArrayList<PlayerConnection> pcsToCount = new ArrayList<>();
        for (PlayerConnection pc : this.clients.values()) {
            if (pc.kullanici.peynir > 100_000) {
                pcsToCount.add(pc);
            }
        }
        MFServer.RoomExecutor.execute(() -> {
            for (PlayerConnection pc : pcsToCount) {
                Long count = MFServer.colRekorlar.count(new Document("rekorlar.0.ad", pc.kullanici.isim));
                if (count >= rek.get()) {
                    rek.set(count);
                    kullanici1[0] = pc;
                }
            }
            src.onResult(kullanici1[0]);
        });


    }

    public void tacYolla() throws IOException {
        kraliVer((PlayerConnection kral) -> {

            this.sonKral = kral;
            if (kral != null) {

                ByteBufOutputStream p = MFServer.getStream();
                try {
                    p.writeByte(29);

                    p.writeByte(19);

                    p.writeInt(987);
                    p.writeUTF("9f26ee3a398f11e78ef9109836a51f7d.png");
                    p.writeByte(2);
                    p.writeInt(kral.kullanici.code);
                    p.writeShort(-25);
                    p.writeShort(-70);
                    ByteBuf packet = p.buffer();
                    for (PlayerConnection client : clients.values()) {

                        if (client.crown) client.sendPacket(packet.retainedSlice());
                    }
                    packet.release();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //MFServer.bitti(p.buffer());
                // packet.release();

            }
        });

    }

    public void showColorPicker(int id, String target, int defaultColor, String title) {
        try {

            ByteBufOutputStream p = MFServer.getStream();
            p.writeByte(29);
            p.writeByte(32);
            p.writeInt(id);
            p.writeInt(defaultColor);
            p.writeUTF(title);

            if (target.length() == 0) {
                this.sendAll(p.buffer());
            } else {
                sendTarget(target, p.buffer());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int addShamanObject(int code, int x, int y, int angle, int vx, int vy, boolean ghost,
                               ArrayList<Integer> shaman_colors, int pC) throws IOException {

        int oi = this.ObjectID.addAndGet(1);

        ByteBufOutputStream p = MFServer.getStream();
        p.writeByte(5);
        p.writeByte(20);
        p.writeInt(oi);
        p.writeShort(code);
        p.writeShort(x);
        p.writeShort(y);
        p.writeShort(angle);
        p.writeByte(vx);
        p.writeByte(vy);
        p.writeBoolean(ghost);
        if (shaman_colors != null) {
            p.writeByte(shaman_colors.size());
            for (Integer color : shaman_colors) {
                p.writeInt(color);
            }
        } else {
            p.writeByte(0);
        }
        if (pC == 0) {

            this.sendAll(p.buffer());
        } else {
            this.sendAllOthers(p.buffer(), pC);
        }
        if (this.l_room != null) {

            LuaTable tab = new LuaTable();
            tab.set("x", x);
            tab.set("y", y);
            tab.set("vx", vx);
            tab.set("vy", vy);
            tab.set("angle", angle);
            tab.set("ghost", ghost ? 1 : 0);
            tab.set("type", code);
            tab.set("id", oi);
            this.objectList.put(oi, tab);

        }
        return oi;

    }

    public int addShamanObject(int code, int x, int y) throws IOException {
        return this.addShamanObject(code, x, y, 0, 0, 0, false, null, 0);
    }

    public int addShamanObject(int code, int x, int y, int angle, int vx, int vy) throws IOException {
        return this.addShamanObject(code, x, y, angle, vx, vy, false, null, 0);
    }

    public int addShamanObject(int code, int x, int y, int angle, int vx, int vy, boolean ghost,
                               ArrayList<Integer> shaman_colors) throws IOException {
        return this.addShamanObject(code, x, y, angle, vx, vy, ghost, shaman_colors, 0);

        // if (this.luaMinigame != null) {
        // Map<String, Integer> object = new HashMap();
        // object.put("x", x);
        // object.put("y", y);
        // object.put("angle", angle);
        // object.put("ghost", ghost);
        // object.put("type", code);
        // object.put("id", this.ObjectID);
        // this.objectList.put(this.ObjectID, object);
        // this.refreshObjectList();
        // }
    }

    public void kill_afk_players() throws IOException {
        if (this.isEditeur && !this.workEditeur) return;
        for (PlayerConnection cl : this.clients.values()) {
            if (cl.isAfk && !cl.isDead) {
                this.sendDeath(cl);
            }
        }
        this.checkShouldChangeCarte();
    }

    public void setNameColor(PlayerConnection pc, int color) throws IOException {
        ByteBufOutputStream p = MFServer.getStream();
        p.writeByte(29);
        p.writeByte(4);
        p.writeInt(pc.kullanici.code);
        p.writeInt(color);
        this.sendAll(p.buffer());
    }

    public void movePlayer(PlayerConnection pc, int x, int y, boolean positionOffset, int xSpeed, int ySpeed,
                           boolean speedOffset) throws IOException {
        pc.move(x, y, positionOffset, xSpeed, ySpeed, speedOffset);
    }

    public void movePlayer(PlayerConnection pc, int x, int y) throws IOException {
        pc.move(x, y, false, 0, 0, false);
    }

    public static class FuncorpSettings {
        private final Room room;
        public HashMap<String, String> chatColors = new HashMap<>();
        public HashMap<Integer, Integer> miceSize = new HashMap<>();
        public HashMap<String, Integer> miceNickColors = new HashMap<>();
        public HashMap<String, String> miceNames = new HashMap<>();

        public FuncorpSettings(Room room) {
            this.room = room;
        }

        public static String packColor(String message, String color) {
            if (color.isEmpty()) return message;
            return "<font color=\"#" + color + "\">" + message + "</font>";
        }

        public void sendMessage(String name, String message) throws IOException {

            String color = this.chatColors.getOrDefault(name, "");
            name = this.room.funcorpSettings.miceNames.getOrDefault(name, name);
            room.sendMessage(packColor("[<a href=\"event:clicTexteNomJoueurEvent;joueur=" + name + "&online=true\" class=\"auteur\">" + name + "</a>] <n>", color) + message + "</n>");
        }

        public void sendSize(Integer code) throws IOException {
            Integer size = miceSize.get(code);
            if (size != null)
                this.room.sendAll(MFServer.getBuf().writeByte(5).writeByte(31).writeInt(code).writeShort(size).writeByte(0));
        }

        public void sendColor(PlayerConnection pc) throws IOException {
            Integer col = miceNickColors.get(pc.kullanici.isim);
            if (col != null) room.setNameColor(pc, col);
        }


    }

    public static class MusicVideo {
        public String title;
        public String kullanici;
        public String vid;
        public int sure;

        public MusicVideo(String kullanici, String vid, int sure, String title) {
            this.kullanici = kullanici;
            this.vid = vid;
            this.sure = sure;
            this.title = title;
        }
    }

}
