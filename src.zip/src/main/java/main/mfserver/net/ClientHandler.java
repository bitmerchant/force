/**
 * This file is part of Ogar.
 * <p>
 * Ogar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * Ogar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with Ogar.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfserver.net;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;
import mfserver.main.MFServer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClientHandler extends SimpleChannelInboundHandler<ByteBuf> {
    public static Map<String,Integer> IP_LIST= new ConcurrentHashMap<>();
    public final MFServer server;
    public String ip;
    private PlayerConnection player;

    public ClientHandler(MFServer server, String ip) {
        this.server = server;
        this.ip = ip;

    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {

		if (this.server.IP_BANS.containsKey(ip)) {
            ctx.channel().close();
			return;
		}
		Integer count=IP_LIST.getOrDefault(ip,0);
		if (count>80){
            System.out.println(ip);
            ctx.channel().close();
            return;
        }
        count+=1;
		IP_LIST.put(ip,count);
        this.player = new PlayerConnection(this, ctx.channel());

    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
      //  System.out.println(evt);
        if (evt instanceof IdleStateEvent) {
            ctx.channel().close();
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        // server.getPlayerList().removePlayer(player);
        if (player != null) player.disc();
        player = null;
        Integer count=IP_LIST.getOrDefault(ip,0);
        count-=1;
        if(count>0)IP_LIST.put(ip,count);
        else IP_LIST.remove(ip);

    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, ByteBuf buf) throws Exception {
        player.handle(buf);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
      //  System.out.println(cause);
       // MFServer.log.warning( MFServer.stackTraceToString(cause));
        if (!(cause instanceof IOException)) {
            String name = "";
            if (player != null&&player.kullanici!=null) name = player.kullanici.isim;
            MFServer.log.warning("[" + name + "]" + MFServer.stackTraceToString(cause));

        }
        ctx.channel().close();
    }

}
