/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.net;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/**
 * @author sevendr
 */
public class RawData extends MessageToByteEncoder<byte[]> {
    public static String pw = "Vc^ZerX7zQJFcfBn*[9NKm]!RGVCt{v3*!ZFX'5q;]e<Y";

    @Override
    public void encode(ChannelHandlerContext ctx, byte[] msg, ByteBuf out) throws Exception {
        // out.writeByte(2);

        // System.out.println("aha");
        // out.writeShort(msg.length);
        out.writeBytes(msg);
    }
}
