package mfserver.util;

/**
 * Created by sevendr on 24.09.2017.
 */
public class An {
    public String pn;
    public int vx;
    public int vy;

    public An(String pn, int vx, int vy) {
        this.pn = pn;
        this.vx = vx;
        this.vy = vy;
    }
}
