package mfserver.util;

public class Daire {
    public int id;
    public int x;
    public int y;
    public int cap;

    public Daire(int id, int cap, int x, int y) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.cap = cap;
    }

    public boolean carpisma(int X, int Y) {
        return false;
    }
}
