package mfserver.util;

import java.util.HashMap;
import java.util.HashSet;

/**
 * Created by sevendr on 6.06.2017.
 */
public class Etkinlik {
    public int id = 20;
    public int tarih;
    public HashSet<Integer> unvanlar = new HashSet<>();
    public HashMap<Integer, Integer> rozetler = new HashMap<>();
    public HashSet<Integer> kalintilar = new HashSet<>();

}
