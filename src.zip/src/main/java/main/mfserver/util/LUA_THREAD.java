/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.util;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.L_Room;
import org.luaj.vm2.lib.jse.JsePlatform;
import veritabani.SRC;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

/**
 * @author sevendr
 */
public class LUA_THREAD extends Thread {

    public L_Room l_room;
    public boolean interrupted;
    public long time;
    public BlockingDeque<Event> events = new LinkedBlockingDeque<>();
    public List<Event> events2 = Collections.synchronizedList(new ArrayList<Event>());
    private SRC cb;
    public int limit;

    public LUA_THREAD(L_Room l_room, SRC cb) {
        this.l_room = l_room;
        this.time = System.currentTimeMillis();
        this.cb = cb;
        this.limit=10000;
    }

    @Override
    public void run() {
        this.setName("LUA Thread " + this.l_room.toString());
        boolean hasLoop = false;

        this.time = System.currentTimeMillis();
        Globals globals = JsePlatform.standardGlobals(this.l_room);

        try {

            this.l_room.global = globals;
            LuaValue chunk = globals.loadfile(this.l_room.room.LUAFile);

            this.time = System.currentTimeMillis();

            try {
                chunk.call();
            } catch (Exception ex) {
            //    ex.printStackTrace();
                // this.l_room.sendLuaMessage(ex.getMessage());
                this.l_room.room.l_room = null;
                this.l_room.room.isMinigame = false;
                // this.l_room.sendError(ex.getMessage());
                return;

            }

        } catch (LuaError ex) {
            //ex.printStackTrace();
            this.l_room.sendLuaMessage(ex.getMessage());
            this.l_room.room.l_room = null;
            this.l_room.room.isMinigame = false;
        }
        if (!this.l_room.custom) {

                this.l_room.room.NewRound();

        }
        cb.onResult(null);
        this.cb = null;
        LuaValue loop = globals.get("eventLoop");

        hasLoop = loop != LuaValue.NIL;
        this.time = System.currentTimeMillis();

        long lastLoop = 0;
        int eventCount = 0;
        while (!l_room.get_interrupted()) {
            try {
                while (!l_room.get_interrupted()) {
                    if (eventCount++ > 50)
                        break;
                    Iterator<Event> it = events2.iterator();
                    while (it.hasNext()){
                        Event ev=it.next();
                        if(ev.deadline<=System.currentTimeMillis()){
                            ev.fonk.invoke(ev.degerler);
                            it.remove();
                        }
                    }
                    Event event = events.poll(5, TimeUnit.MILLISECONDS);
                    if (event == null)
                        break;
                    LuaValue fonk = this.l_room.global.get(event.fonksiyon);
                    if (!fonk.isnil()) {
                        fonk.invoke(event.degerler);
                    }

                }
                if (hasLoop && System.currentTimeMillis() - lastLoop >= this.l_room.eventMs) {
                    LuaValue[] l = this.l_room.room.getRoundTime2();
                    loop.call(l[0], l[1]);
                    lastLoop = System.currentTimeMillis();
                }
                this.l_room.call_count.set(0);
                this.time = System.currentTimeMillis();
                eventCount = 0;
            } catch (Exception ex) {
                this.l_room.sendError(ex);

                break;
            }
        }
        if (this.l_room != null) {
            this.l_room.room.closeLua();
        }

    }

}
