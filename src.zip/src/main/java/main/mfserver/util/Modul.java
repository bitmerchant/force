package mfserver.util;

/**
 * Created by sevendr on 26.05.2017.
 */
public class Modul {
    public String ad;


    public String path;
    public boolean official;

    public Modul(String ad, String path, boolean official) {
        this.ad = ad;
        this.path = path;
        this.official = official;
    }

}
