package mfserver.util;

/**
 * Created by sevendr on 21.07.2017.
 */
public class MulodromePlayer {
    public int code;
    public int pos;
    public int team;
    public String tribeName = "";
    public String name;

/*    @Override
    public int hashCode() {
        return code;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MulodromePlayer) {
            MulodromePlayer mulodromePlayer = (MulodromePlayer) obj;
            return code == mulodromePlayer.code;
        }
        return ((Integer) obj).equals(code);
    }*/
}
