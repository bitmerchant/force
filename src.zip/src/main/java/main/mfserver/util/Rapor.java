package mfserver.util;

/**
 * Created by sevendr on 30.04.2017.
 */
public class Rapor {
    public String raporlayan;
    public String sebep;
    public int typ;
    public int karma;
}
