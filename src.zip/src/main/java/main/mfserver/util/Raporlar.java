package mfserver.util;

import java.util.ArrayList;

/**
 * Created by sevendr on 30.04.2017.
 */
public class Raporlar {
    public ArrayList<Rapor> arr = new ArrayList<>();
    public int surev;
    public String dil;
    public String ad;
    public String silen = "";

    //public ArrayList<String> yanlar=new ArrayList<>();
    public String oda;

    public String toString() {
        return arr.size() + " - " + surev;
    }
}
