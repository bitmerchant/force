package mfserver.util;

import java.util.concurrent.ScheduledFuture;

/**
 * Created by sevendr on 23.03.2017.
 */
public class Susturma {
    public String sebep = "";
    public String ip = "";
    public ScheduledFuture bitis;
    public int saat = 0;

}
