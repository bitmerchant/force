package mfserver.util;

/**
 * Created by sevendr on 24.05.2017.
 */
public class Yasaklama {
    public String yasaklayan;
    public String sebep;
    public String yasaklanan;
    public int surev;

}
