/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfserver.util;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author sevendr
 */
public class map {
    public int id = -1;
    public Integer perm = 0;
    public String xml = "";
    public String name = "";

    public map() {

    }

    public map load(ResultSet d) throws SQLException {
        this.id = d.getInt("id");
        this.perm = d.getInt("perm");
        this.xml = d.getString("xml");
        this.name = d.getString("name");
        return this;
    }

    public void insert() {
        /*
		 * MFServer.instance.col_maps.insertOne(new Document("_id", 1), null);
		 */
    }
}
