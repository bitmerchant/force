package veritabani;

public class Ceza {
    public String ad;
    public String yetkili="";
    public String sebep ="None";
    public String oda="";
    public String ip="";
    public Long surev;
    public int surec;
    public int tip=0;
    public Ceza(){
    }


    public Ceza(String ad, String yetkili, Long surev, int surec) {
        this.ad = ad;
        this.yetkili = yetkili;
        this.surev = surev;
        this.surec = surec;
    }
}
