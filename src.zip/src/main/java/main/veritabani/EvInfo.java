package veritabani;

import java.util.HashSet;
import java.util.LinkedHashMap;

public class EvInfo {
    public int n23 = 0;
    public int e31 = 0;
    public int fircalar = 0;
    public int unvanYenilemesi = 0;
    public int gorevBileti=0;
    public int paskalyaGorevleri=0;
    public int tag=0;
    public LinkedHashMap<String,String> titles=new LinkedHashMap<>();
    public boolean sessizSifirlandi=false;
    public int seviyeSifirlandi=0;
    public int cadilarGorevleri=0;
    public int cadilarHediye=0;
    public int becerilerSifirlandi=0;
    public int eksiler=0;
    public int yilbasi2018Gorevleri2=0;
    public int dragonEvent2019Gorevleri=0;
}
