package veritabani;

public class ExtraStats{
        public ExtraStats(){}
        public int racing_comp_rounds=0;
        public int racing_rounds=0;
        public int racing_first=0;
        public int racing_podium=0;
        public int survivor=0;
        public int survivor_shaman=0;
        public int survivor_rounds=0;
        public int survivor_killed;
        public int kutier_survivor=0;
        public int kutier_killed=0;
        public int defilante=0;
    }