package veritabani;

import mfserver.main.MFServer;
import mfserver.util.VanillaMap;
import mfserver.util.map;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author sevendr
 */
public class Harita {

    public static void haritalar(MFServer server) {
        MFServer.executor.execute(() -> {

            try (Connection connection = MFServer.DS.getConnection();
                 PreparedStatement statement = connection.prepareStatement("select id,perm from maps"); PreparedStatement statement1 = connection.prepareStatement("set sql_mode=\"STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION\"")) {

                ResultSet rs = statement.executeQuery();
                while (rs.next()) {
                    int _id = rs.getInt(1);
                    int perm = rs.getInt(2);
                    ArrayList<Integer> l = server.perms.computeIfAbsent(perm, k -> new ArrayList<>());
                    l.add(_id);
                }
                statement1.execute();

                System.out.println("MAPS LOADED");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public static map al(Integer mapCode) {
        try (Connection connection = MFServer.DS.getConnection();
             PreparedStatement statement = connection.prepareStatement("select * FROM maps where id =?")) {
            statement.setInt(1, mapCode);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return new map().load(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return VanillaMap.get(0);
    }
    public static map alRacing(Integer mapCode) {
        try (Connection connection = MFServer.DS.getConnection();
             PreparedStatement statement = connection.prepareStatement("select * FROM maps where id =?")) {
            statement.setInt(1, mapCode);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                map Map=new map().load(rs);
                Map.perm=17;
                Map.name=MFServer.getPerms(new int[]{17}).name;
                Map.id=57895+MFServer.random.nextInt(100_000);
                return Map;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return VanillaMap.get(0);
    }


}
