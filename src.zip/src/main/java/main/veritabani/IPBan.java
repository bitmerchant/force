package veritabani;

/**
 * Created by sevendr on 13.09.2017.
 */
public final class IPBan {
    public String _id;
    public long deadline;

}
