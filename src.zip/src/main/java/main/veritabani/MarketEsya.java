package veritabani;

import java.util.ArrayList;

public class MarketEsya{
        public int kategori;
        public boolean kisisellestirme;
        public boolean kullan;
        public ArrayList<Integer> renkler=new ArrayList<>();
    public MarketEsya() {
        this.kategori = kategori;
    }
        public MarketEsya(int kategori) {
            this.kategori = kategori;
        }

    public MarketEsya(int kategori, boolean kisisellestirme) {
        this.kategori = kategori;
        this.kisisellestirme = kisisellestirme;
    }

    public MarketEsya(int kategori, boolean kisisellestirme, ArrayList<Integer> renkler) {
        this.kategori = kategori;
        this.kisisellestirme = kisisellestirme;
        this.renkler = renkler;
    }
}