package veritabani;

/**
 * Created by sevendr on 10.05.2017.
 */
public final class Rekor {
    public String ad;
    public Long zaman;
    public Double sure;
    public int hid=-1;
    public long deadline=0;
}

