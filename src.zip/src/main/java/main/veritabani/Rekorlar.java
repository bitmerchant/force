package veritabani;

import java.util.ArrayList;

public final class Rekorlar {
    public int _id;//Harita
    public ArrayList<Rekor> rekorlar;

}
