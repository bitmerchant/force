package veritabani;

public class Sessiz {
    public String ileti;
    public int tip;
}
