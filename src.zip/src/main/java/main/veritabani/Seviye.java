package veritabani;

public class Seviye {
    public int seviye=101;
    public int xp=0;
    public int sonrakiXp=32;
}
